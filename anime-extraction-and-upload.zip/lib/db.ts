// MongoDB connection utility
// Using native MongoDB driver for better control

import { MongoClient, type Db, type Collection } from "mongodb"
import type { Series, Episode, User, Comment, ScraperJob } from "./types"

const MONGODB_URI = process.env.MONGODB_URI || "mongodb://localhost:27017"
const DB_NAME = process.env.DB_NAME || "anicrew"

let client: MongoClient | null = null
let db: Db | null = null

export async function connectDB(): Promise<Db> {
  if (db) return db

  try {
    client = new MongoClient(MONGODB_URI)
    await client.connect()
    db = client.db(DB_NAME)
    console.log("Connected to MongoDB")
    return db
  } catch (error) {
    console.error("MongoDB connection error:", error)
    throw error
  }
}

export async function getCollection<T extends object>(name: string): Promise<Collection<T>> {
  const database = await connectDB()
  return database.collection<T>(name)
}

// Collection getters
export const getSeriesCollection = () => getCollection<Series>("series")
export const getEpisodesCollection = () => getCollection<Episode>("episodes")
export const getUsersCollection = () => getCollection<User>("users")
export const getCommentsCollection = () => getCollection<Comment>("comments")
export const getJobsCollection = () => getCollection<ScraperJob>("jobs")

// Create indexes for better performance
export async function setupIndexes(): Promise<void> {
  const series = await getSeriesCollection()
  const episodes = await getEpisodesCollection()
  const users = await getUsersCollection()
  const comments = await getCommentsCollection()
  const jobs = await getJobsCollection()

  await series.createIndex({ slug: 1 }, { unique: true })
  await series.createIndex({ source: 1, sourceId: 1 })
  await series.createIndex({ title: "text", description: "text" })

  await episodes.createIndex({ seriesId: 1, episodeNumber: 1 })
  await episodes.createIndex({ status: 1 })

  await users.createIndex({ email: 1 }, { unique: true })
  await users.createIndex({ username: 1 }, { unique: true })
  await users.createIndex({ googleId: 1 }, { sparse: true })

  await comments.createIndex({ seriesId: 1 })
  await comments.createIndex({ episodeId: 1 })

  await jobs.createIndex({ status: 1 })
  await jobs.createIndex({ createdAt: -1 })
}
