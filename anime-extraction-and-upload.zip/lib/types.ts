// ==================== DATABASE TYPES ====================

export interface Series {
  _id?: string
  title: string
  slug: string
  poster: string
  banner?: string
  description: string
  source: "hianime" | "tpxsub" | "desidub"
  sourceUrl: string
  sourceId: string
  type: "anime" | "donghua"
  status: "ongoing" | "completed" | "upcoming"
  language: string[]
  genres: string[]
  year?: number
  rating?: number
  totalEpisodes?: number
  createdAt: Date
  updatedAt: Date
}

export interface Episode {
  _id?: string
  seriesId: string
  episodeNumber: number
  title: string
  thumbnail?: string
  duration?: number
  status: "pending" | "extracting" | "downloading" | "uploading" | "uploaded" | "failed"
  streamUrl?: string
  downloadUrl?: string
  remoteId?: string // DoodStream filecode
  languages: {
    audio: string
    subtitle?: string
    streamUrl: string
    downloadUrl?: string
    remoteId?: string
  }[]
  retries: number
  errorMessage?: string
  createdAt: Date
  updatedAt: Date
}

export interface User {
  _id?: string
  googleId?: string
  email: string
  username: string
  displayName: string
  avatar?: string
  role: "user" | "premium" | "admin" | "owner"
  premiumExpiry?: Date
  watchlist: string[]
  watchHistory: {
    seriesId: string
    episodeId: string
    progress: number
    watchedAt: Date
  }[]
  createdAt: Date
  updatedAt: Date
}

export interface Comment {
  _id?: string
  userId: string
  seriesId: string
  episodeId?: string
  content: string
  likes: string[]
  replies: {
    userId: string
    content: string
    createdAt: Date
  }[]
  createdAt: Date
  updatedAt: Date
}

export interface ScraperJob {
  _id?: string
  type: "search" | "episodes" | "download" | "upload"
  source: "hianime" | "tpxsub" | "desidub"
  status: "pending" | "running" | "completed" | "failed"
  seriesId?: string
  episodeId?: string
  progress: number
  message?: string
  createdAt: Date
  updatedAt: Date
}

export interface SiteStats {
  totalUsers: number
  premiumUsers: number
  guestUsers: number
  activeUsers: number
  totalAnime: number
  totalDonghua: number
  totalEpisodes: number
  liveViewers: number
}

// ==================== API TYPES ====================

export interface HiAnimeSearchResult {
  id: string
  title: string
  poster: string
  type: string
  episodes?: {
    sub: number
    dub: number
  }
}

export interface HiAnimeEpisode {
  id: string
  number: number
  title: string
  isFiller: boolean
}

export interface HiAnimeSource {
  quality: string
  url: string
  isM3U8: boolean
}

export interface TPXEpisode {
  number: number
  links: {
    host: string
    url: string
  }[]
}

export interface DesiDubEpisode {
  number: number
  iframeUrl: string
  streamUrl?: string
}

// ==================== DOODSTREAM API ====================

export interface DoodStreamUploadResponse {
  status: number
  msg: string
  result: {
    filecode: string
    download_url: string
    single_img: string
    splash_img: string
  }
}

export interface DoodStreamFileInfo {
  filecode: string
  title: string
  views: number
  uploaded: string
  length: number
  canplay: boolean
}

// ==================== THEME TYPES ====================

export type ThemeMode = "light" | "dark" | "special"

export interface Theme {
  id: string
  name: string
  mode: ThemeMode
  colors: {
    background: string
    foreground: string
    card: string
    cardForeground: string
    primary: string
    primaryForeground: string
    secondary: string
    secondaryForeground: string
    muted: string
    mutedForeground: string
    accent: string
    accentForeground: string
    border: string
    ring: string
  }
  animation?:
    | "sakura"
    | "rain"
    | "aurora"
    | "galaxy"
    | "flame"
    | "snow"
    | "smoke"
    | "solar"
    | "fog"
    | "ember"
    | "wave"
    | "portal"
}

// ==================== STREAMING TYPES ====================

export interface StreamSource {
  quality: string
  url: string
  type: "m3u8" | "mp4" | "embed"
}

export interface SubtitleTrack {
  label: string
  language: string
  url: string
}
