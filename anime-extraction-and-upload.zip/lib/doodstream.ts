// DoodStream Upload & Management API

import type { DoodStreamUploadResponse, DoodStreamFileInfo } from "./types"

const DOOD_API_KEY = process.env.DOODSTREAM_API_KEY || ""
const DOOD_BASE_URL = "https://doodapi.com/api"

export class DoodStreamClient {
  private apiKey: string

  constructor(apiKey?: string) {
    this.apiKey = apiKey || DOOD_API_KEY
  }

  // Get account info
  async getAccountInfo(): Promise<{ email: string; balance: string } | null> {
    try {
      const response = await fetch(`${DOOD_BASE_URL}/account/info?key=${this.apiKey}`)
      const data = await response.json()
      return data.status === 200 ? data.result : null
    } catch (error) {
      console.error("DoodStream account info error:", error)
      return null
    }
  }

  // Get upload server URL
  async getUploadServer(): Promise<string | null> {
    try {
      const response = await fetch(`${DOOD_BASE_URL}/upload/server?key=${this.apiKey}`)
      const data = await response.json()
      return data.status === 200 ? data.result : null
    } catch (error) {
      console.error("DoodStream upload server error:", error)
      return null
    }
  }

  // Upload file from URL (remote upload)
  async uploadFromUrl(url: string, title?: string, folderId?: string): Promise<DoodStreamUploadResponse | null> {
    try {
      let uploadUrl = `${DOOD_BASE_URL}/upload/url?key=${this.apiKey}&url=${encodeURIComponent(url)}`

      if (title) uploadUrl += `&title=${encodeURIComponent(title)}`
      if (folderId) uploadUrl += `&fld_id=${folderId}`

      const response = await fetch(uploadUrl)
      const data = await response.json()

      return data.status === 200 ? data : null
    } catch (error) {
      console.error("DoodStream remote upload error:", error)
      return null
    }
  }

  // Check remote upload status
  async checkUploadStatus(fileCode: string): Promise<{
    status: string
    progress?: number
  } | null> {
    try {
      const response = await fetch(`${DOOD_BASE_URL}/urlupload/status?key=${this.apiKey}&file_code=${fileCode}`)
      const data = await response.json()
      return data.status === 200 ? data.result : null
    } catch (error) {
      console.error("DoodStream status check error:", error)
      return null
    }
  }

  // Get file info
  async getFileInfo(fileCode: string): Promise<DoodStreamFileInfo | null> {
    try {
      const response = await fetch(`${DOOD_BASE_URL}/file/info?key=${this.apiKey}&file_code=${fileCode}`)
      const data = await response.json()
      return data.status === 200 && data.result?.length > 0 ? data.result[0] : null
    } catch (error) {
      console.error("DoodStream file info error:", error)
      return null
    }
  }

  // List files in folder
  async listFiles(
    folderId?: string,
    page = 1,
  ): Promise<{
    files: DoodStreamFileInfo[]
    totalPages: number
  }> {
    try {
      let url = `${DOOD_BASE_URL}/file/list?key=${this.apiKey}&page=${page}`
      if (folderId) url += `&fld_id=${folderId}`

      const response = await fetch(url)
      const data = await response.json()

      return data.status === 200
        ? { files: data.result.files || [], totalPages: data.result.total_pages || 1 }
        : { files: [], totalPages: 1 }
    } catch (error) {
      console.error("DoodStream list files error:", error)
      return { files: [], totalPages: 1 }
    }
  }

  // Create folder
  async createFolder(name: string, parentId?: string): Promise<string | null> {
    try {
      let url = `${DOOD_BASE_URL}/folder/create?key=${this.apiKey}&name=${encodeURIComponent(name)}`
      if (parentId) url += `&parent_id=${parentId}`

      const response = await fetch(url)
      const data = await response.json()

      return data.status === 200 ? data.result.fld_id : null
    } catch (error) {
      console.error("DoodStream create folder error:", error)
      return null
    }
  }

  // Get embed URL
  getEmbedUrl(fileCode: string): string {
    return `https://dood.so/e/${fileCode}`
  }

  // Get download URL (requires premium for direct)
  async getDownloadUrl(fileCode: string): Promise<string | null> {
    try {
      const response = await fetch(`${DOOD_BASE_URL}/file/direct_link?key=${this.apiKey}&file_code=${fileCode}`)
      const data = await response.json()
      return data.status === 200 ? data.result : null
    } catch (error) {
      console.error("DoodStream download URL error:", error)
      return null
    }
  }

  // Delete file
  async deleteFile(fileCode: string): Promise<boolean> {
    try {
      const response = await fetch(`${DOOD_BASE_URL}/file/delete?key=${this.apiKey}&file_code=${fileCode}`)
      const data = await response.json()
      return data.status === 200
    } catch (error) {
      console.error("DoodStream delete error:", error)
      return false
    }
  }
}

export const doodstream = new DoodStreamClient()
