// Download & Upload Queue Manager
// Handles background processing of video downloads and uploads

import { getEpisodesCollection, getJobsCollection, getSeriesCollection } from "./db"
import { sourceAdapter } from "./source-adapters"
import { doodstream } from "./doodstream"

interface QueueJob {
  episodeId: string
  seriesId: string
  source: "hianime" | "tpxsub" | "desidub"
  episodeNumber: number
  sourceEpisodeId: string
  episodeUrl?: string
}

class DownloadQueue {
  private queue: QueueJob[] = []
  private processing = false
  private maxConcurrent = 2
  private activeJobs = 0
  private initialized = false

  async initialize(): Promise<void> {
    if (this.initialized) return
    this.initialized = true

    try {
      const jobs = await getJobsCollection()
      const episodes = await getEpisodesCollection()
      const series = await getSeriesCollection()

      // Find all pending/running jobs that need to be re-processed
      const pendingJobs = await jobs
        .find({
          status: { $in: ["pending", "running"] },
          type: "download",
        })
        .toArray()

      console.log(`[Queue] Found ${pendingJobs.length} pending jobs to resume`)

      for (const job of pendingJobs) {
        // Get episode details
        const episode = await episodes.findOne({ _id: job.episodeId as any })
        const seriesDoc = await series.findOne({ _id: job.seriesId as any })

        if (episode && seriesDoc) {
          this.queue.push({
            episodeId: job.episodeId,
            seriesId: job.seriesId,
            source: seriesDoc.source as "hianime" | "tpxsub" | "desidub",
            episodeNumber: episode.episodeNumber,
            sourceEpisodeId: `${seriesDoc.sourceId}-episode-${episode.episodeNumber}`,
            episodeUrl: seriesDoc.sourceUrl ? `${seriesDoc.sourceUrl}/episode-${episode.episodeNumber}` : undefined,
          })
        }
      }

      // Also re-queue any episodes that were in extracting/downloading/uploading state
      const stuckEpisodes = await episodes
        .find({
          status: { $in: ["extracting", "downloading", "uploading"] },
        })
        .toArray()

      console.log(`[Queue] Found ${stuckEpisodes.length} stuck episodes to retry`)

      for (const ep of stuckEpisodes) {
        // Reset status to pending
        await episodes.updateOne({ _id: ep._id }, { $set: { status: "pending", updatedAt: new Date() } })

        const seriesDoc = await series.findOne({ _id: ep.seriesId as any })
        if (seriesDoc) {
          // Check if not already in queue
          const alreadyQueued = this.queue.some((q) => q.episodeId === ep._id?.toString())
          if (!alreadyQueued) {
            this.queue.push({
              episodeId: ep._id?.toString() || "",
              seriesId: ep.seriesId,
              source: seriesDoc.source as "hianime" | "tpxsub" | "desidub",
              episodeNumber: ep.episodeNumber,
              sourceEpisodeId: `${seriesDoc.sourceId}-episode-${ep.episodeNumber}`,
              episodeUrl: seriesDoc.sourceUrl ? `${seriesDoc.sourceUrl}/episode-${ep.episodeNumber}` : undefined,
            })
          }
        }
      }

      if (this.queue.length > 0) {
        console.log(`[Queue] Starting to process ${this.queue.length} queued jobs`)
        this.processQueue()
      }
    } catch (error) {
      console.error("[Queue] Failed to initialize queue:", error)
    }
  }

  // Add job to queue
  async addJob(job: QueueJob): Promise<void> {
    // Make sure queue is initialized
    await this.initialize()

    // Check if job already exists in queue
    const exists = this.queue.some((q) => q.episodeId === job.episodeId)
    if (exists) {
      console.log(`[Queue] Job already queued: ${job.episodeId}`)
      return
    }

    this.queue.push(job)

    // Create job record in DB
    const jobs = await getJobsCollection()

    // Upsert to avoid duplicates
    await jobs.updateOne(
      { episodeId: job.episodeId, type: "download" },
      {
        $set: {
          type: "download",
          source: job.source,
          status: "pending",
          seriesId: job.seriesId,
          episodeId: job.episodeId,
          progress: 0,
          updatedAt: new Date(),
        },
        $setOnInsert: {
          createdAt: new Date(),
        },
      },
      { upsert: true },
    )

    console.log(`[Queue] Added job: ${job.episodeId}`)
    this.processQueue()
  }

  // Process queue
  private async processQueue(): Promise<void> {
    if (this.processing || this.activeJobs >= this.maxConcurrent) return

    this.processing = true

    while (this.queue.length > 0 && this.activeJobs < this.maxConcurrent) {
      const job = this.queue.shift()
      if (job) {
        this.activeJobs++
        console.log(`[Queue] Processing job: ${job.episodeId}, Active: ${this.activeJobs}`)
        this.processJob(job).finally(() => {
          this.activeJobs--
          this.processQueue()
        })
      }
    }

    this.processing = false
  }

  // Process single job
  private async processJob(job: QueueJob): Promise<void> {
    const episodes = await getEpisodesCollection()
    const jobs = await getJobsCollection()

    try {
      // Update status to extracting
      await episodes.updateOne({ _id: job.episodeId as any }, { $set: { status: "extracting", updatedAt: new Date() } })

      await jobs.updateOne(
        { episodeId: job.episodeId, type: "download" },
        { $set: { status: "running", message: "Extracting stream URL...", updatedAt: new Date() } },
      )

      console.log(`[Queue] Extracting stream for episode: ${job.episodeId}`)

      // Get stream URL from source
      const episodeData = await sourceAdapter.getEpisode(job.source, job.sourceEpisodeId, job.episodeUrl)

      if (!episodeData?.streamUrl && !episodeData?.downloadLinks?.length) {
        throw new Error("No stream URL found")
      }

      const streamUrl = episodeData.streamUrl || episodeData.downloadLinks?.[0]?.url

      if (!streamUrl) {
        throw new Error("No valid stream URL")
      }

      console.log(`[Queue] Got stream URL: ${streamUrl.substring(0, 50)}...`)

      // Update status to uploading
      await episodes.updateOne(
        { _id: job.episodeId as any },
        { $set: { status: "uploading", streamUrl, updatedAt: new Date() } },
      )

      await jobs.updateOne(
        { episodeId: job.episodeId, type: "download" },
        { $set: { progress: 50, message: "Uploading to DoodStream...", updatedAt: new Date() } },
      )

      // Upload to DoodStream
      const uploadResult = await doodstream.uploadFromUrl(streamUrl, `Episode ${job.episodeNumber}`)

      if (!uploadResult?.result?.filecode) {
        throw new Error("DoodStream upload failed: " + JSON.stringify(uploadResult))
      }

      console.log(`[Queue] Upload complete: ${uploadResult.result.filecode}`)

      // Update episode with DoodStream info
      await episodes.updateOne(
        { _id: job.episodeId as any },
        {
          $set: {
            status: "uploaded",
            remoteId: uploadResult.result.filecode,
            downloadUrl: doodstream.getEmbedUrl(uploadResult.result.filecode),
            updatedAt: new Date(),
          },
        },
      )

      await jobs.updateOne(
        { episodeId: job.episodeId, type: "download" },
        {
          $set: {
            status: "completed",
            progress: 100,
            message: "Upload complete!",
            updatedAt: new Date(),
          },
        },
      )

      console.log(`[Queue] Job completed: ${job.episodeId}`)
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error"
      console.error(`[Queue] Job failed: ${job.episodeId}`, errorMessage)

      // Update episode status to failed
      await episodes.updateOne(
        { _id: job.episodeId as any },
        {
          $set: {
            status: "failed",
            errorMessage,
            updatedAt: new Date(),
          },
          $inc: { retries: 1 },
        },
      )

      await jobs.updateOne(
        { episodeId: job.episodeId, type: "download" },
        {
          $set: {
            status: "failed",
            message: errorMessage,
            updatedAt: new Date(),
          },
        },
      )
    }
  }

  // Get queue status
  getStatus(): { pending: number; active: number; initialized: boolean } {
    return {
      pending: this.queue.length,
      active: this.activeJobs,
      initialized: this.initialized,
    }
  }

  getQueuedJobs(): QueueJob[] {
    return [...this.queue]
  }

  // Retry failed episodes
  async retryFailed(maxRetries = 3): Promise<number> {
    await this.initialize()

    const episodes = await getEpisodesCollection()
    const series = await getSeriesCollection()

    const failedEpisodes = await episodes
      .find({
        status: "failed",
        retries: { $lt: maxRetries },
      })
      .toArray()

    let requeued = 0

    for (const ep of failedEpisodes) {
      const seriesDoc = await series.findOne({ _id: ep.seriesId as any })
      if (seriesDoc) {
        await this.addJob({
          episodeId: ep._id?.toString() || "",
          seriesId: ep.seriesId,
          source: seriesDoc.source as "hianime" | "tpxsub" | "desidub",
          episodeNumber: ep.episodeNumber,
          sourceEpisodeId: `${seriesDoc.sourceId}-episode-${ep.episodeNumber}`,
          episodeUrl: seriesDoc.sourceUrl ? `${seriesDoc.sourceUrl}/episode-${ep.episodeNumber}` : undefined,
        })
        requeued++
      }
    }

    console.log(`[Queue] Re-queued ${requeued} failed episodes`)
    return requeued
  }

  async retryEpisode(episodeId: string): Promise<boolean> {
    await this.initialize()

    const episodes = await getEpisodesCollection()
    const series = await getSeriesCollection()

    const episode = await episodes.findOne({ _id: episodeId as any })
    if (!episode) return false

    const seriesDoc = await series.findOne({ _id: episode.seriesId as any })
    if (!seriesDoc) return false

    // Reset episode status
    await episodes.updateOne(
      { _id: episodeId as any },
      { $set: { status: "pending", errorMessage: null, updatedAt: new Date() } },
    )

    await this.addJob({
      episodeId: episode._id?.toString() || "",
      seriesId: episode.seriesId,
      source: seriesDoc.source as "hianime" | "tpxsub" | "desidub",
      episodeNumber: episode.episodeNumber,
      sourceEpisodeId: `${seriesDoc.sourceId}-episode-${episode.episodeNumber}`,
      episodeUrl: seriesDoc.sourceUrl ? `${seriesDoc.sourceUrl}/episode-${episode.episodeNumber}` : undefined,
    })

    return true
  }
}

export const downloadQueue = new DownloadQueue()

// Auto-initialize on module load (for server startup)
if (typeof window === "undefined") {
  downloadQueue.initialize().catch(console.error)
}
