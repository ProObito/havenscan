// DesiDubAnime Source Adapter - Streaming Based (Medium)
// Handles iframe-based streaming extraction

import type { DesiDubEpisode } from "../types"

const DESIDUB_BASE_URL = process.env.DESIDUB_BASE_URL || "https://desidubanime.com"

export class DesiDubAdapter {
  private baseUrl: string

  constructor() {
    this.baseUrl = DESIDUB_BASE_URL
  }

  // Extract iframe sources from episode page
  private extractIframes(html: string): string[] {
    const iframes: string[] = []

    // Match iframe src attributes
    const iframeRegex = /<iframe[^>]*src=["']([^"']+)["'][^>]*>/gi
    let match

    while ((match = iframeRegex.exec(html)) !== null) {
      if (!iframes.includes(match[1])) {
        iframes.push(match[1])
      }
    }

    // Also check for data-src (lazy loaded iframes)
    const dataSrcRegex = /<iframe[^>]*data-src=["']([^"']+)["'][^>]*>/gi
    while ((match = dataSrcRegex.exec(html)) !== null) {
      if (!iframes.includes(match[1])) {
        iframes.push(match[1])
      }
    }

    return iframes
  }

  // Resolve iframe to actual stream URL
  async resolveIframe(iframeUrl: string): Promise<string | null> {
    try {
      // Handle relative URLs
      const fullUrl = iframeUrl.startsWith("http") ? iframeUrl : `${this.baseUrl}${iframeUrl}`

      const response = await fetch(fullUrl, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
          Referer: this.baseUrl,
        },
      })

      if (!response.ok) return null

      const html = await response.text()

      // Look for direct video source
      const sourcePatterns = [
        /source\s*[:=]\s*["']([^"']+\.m3u8[^"']*)["']/i,
        /file\s*[:=]\s*["']([^"']+\.m3u8[^"']*)["']/i,
        /src\s*[:=]\s*["']([^"']+\.m3u8[^"']*)["']/i,
        /source\s*[:=]\s*["']([^"']+\.mp4[^"']*)["']/i,
        /file\s*[:=]\s*["']([^"']+\.mp4[^"']*)["']/i,
        /https?:\/\/[^"'\s]+\.m3u8[^"'\s]*/i,
        /https?:\/\/[^"'\s]+\.mp4[^"'\s]*/i,
      ]

      for (const pattern of sourcePatterns) {
        const match = html.match(pattern)
        if (match) {
          return match[1] || match[0]
        }
      }

      // Check for nested iframe
      const nestedIframes = this.extractIframes(html)
      if (nestedIframes.length > 0) {
        for (const nestedUrl of nestedIframes) {
          const resolved = await this.resolveIframe(nestedUrl)
          if (resolved) return resolved
        }
      }

      return null
    } catch (error) {
      console.error("DesiDub iframe resolve error:", error)
      return null
    }
  }

  // Get episode stream URL
  async getEpisodeStream(episodeUrl: string): Promise<DesiDubEpisode | null> {
    try {
      const response = await fetch(episodeUrl, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        },
      })

      if (!response.ok) return null

      const html = await response.text()
      const iframes = this.extractIframes(html)

      // Extract episode number
      const epMatch = episodeUrl.match(/episode-?(\d+)/i)
      const episodeNumber = epMatch ? Number.parseInt(epMatch[1]) : 1

      // Try to resolve each iframe
      for (const iframe of iframes) {
        const streamUrl = await this.resolveIframe(iframe)
        if (streamUrl) {
          return {
            number: episodeNumber,
            iframeUrl: iframe,
            streamUrl,
          }
        }
      }

      // Return iframe even if we couldn't resolve stream
      return {
        number: episodeNumber,
        iframeUrl: iframes[0] || "",
        streamUrl: undefined,
      }
    } catch (error) {
      console.error("DesiDub episode error:", error)
      return null
    }
  }

  // Search anime
  async search(query: string): Promise<{ title: string; url: string; poster?: string }[]> {
    try {
      const response = await fetch(`${this.baseUrl}/?s=${encodeURIComponent(query)}`, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        },
      })

      if (!response.ok) return []

      const html = await response.text()
      const results: { title: string; url: string; poster?: string }[] = []

      // Parse search results - adjust regex based on actual site structure
      const itemRegex =
        /<article[^>]*>[\s\S]*?<a[^>]*href=["']([^"']+)["'][^>]*>[\s\S]*?(?:<img[^>]*src=["']([^"']+)["'][^>]*>)?[\s\S]*?<(?:h2|h3|span)[^>]*class=["'][^"']*title[^"']*["'][^>]*>([^<]+)</gi
      let match

      while ((match = itemRegex.exec(html)) !== null) {
        results.push({
          url: match[1],
          poster: match[2] || undefined,
          title: match[3].trim(),
        })
      }

      return results
    } catch (error) {
      console.error("DesiDub search error:", error)
      return []
    }
  }

  // Get anime info
  async getAnimeInfo(animeUrl: string): Promise<{
    title: string
    poster?: string
    description?: string
    episodes: string[]
  } | null> {
    try {
      const response = await fetch(animeUrl, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        },
      })

      if (!response.ok) return null

      const html = await response.text()

      // Extract title
      const titleMatch = html.match(/<h1[^>]*>([^<]+)<\/h1>/i)
      const title = titleMatch?.[1]?.trim() || "Unknown"

      // Extract poster
      const posterMatch = html.match(/<img[^>]*class=["'][^"']*poster[^"']*["'][^>]*src=["']([^"']+)["']/i)
      const poster = posterMatch?.[1]

      // Extract description
      const descMatch = html.match(/<div[^>]*class=["'][^"']*description[^"']*["'][^>]*>([\s\S]*?)<\/div>/i)
      const description = descMatch?.[1]?.replace(/<[^>]+>/g, "").trim()

      // Extract episode links
      const episodes: string[] = []
      const epRegex = /<a[^>]*href=["']([^"']*episode[^"']*)["'][^>]*>/gi
      let match

      while ((match = epRegex.exec(html)) !== null) {
        if (!episodes.includes(match[1])) {
          episodes.push(match[1])
        }
      }

      return {
        title,
        poster,
        description,
        episodes: episodes.sort((a, b) => {
          const numA = Number.parseInt(a.match(/episode-?(\d+)/i)?.[1] || "0")
          const numB = Number.parseInt(b.match(/episode-?(\d+)/i)?.[1] || "0")
          return numA - numB
        }),
      }
    } catch (error) {
      console.error("DesiDub info error:", error)
      return null
    }
  }
}

export const desidubAdapter = new DesiDubAdapter()
