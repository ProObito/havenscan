// TPXSub Source Adapter - Shortener Based (Hardest)
// Handles shortened/redirected links with JS execution

import type { TPXEpisode } from "../types"

const TPX_BASE_URL = process.env.TPX_BASE_URL || "https://tpxsub.com"

export class TPXSubAdapter {
  private baseUrl: string

  constructor() {
    this.baseUrl = TPX_BASE_URL
  }

  // Parse episode page HTML to extract download links
  private parseEpisodePage(html: string): { host: string; shortUrl: string }[] {
    const links: { host: string; shortUrl: string }[] = []

    // Match download buttons with shortened URLs
    // Pattern: <a href="https://short.url/xxx" ... >Host Name</a>
    const buttonRegex = /<a[^>]*href=["']([^"']+)["'][^>]*class=["'][^"']*download[^"']*["'][^>]*>([^<]+)<\/a>/gi
    let match

    while ((match = buttonRegex.exec(html)) !== null) {
      links.push({
        shortUrl: match[1],
        host: match[2].trim(),
      })
    }

    // Also check for onclick handlers with links
    const onclickRegex = /onclick=["'](?:window\.)?(?:open|location)[^"']*["']([^"']+)["']/gi
    while ((match = onclickRegex.exec(html)) !== null) {
      links.push({
        shortUrl: match[1],
        host: "Unknown",
      })
    }

    return links
  }

  // Resolve shortened URL to actual download link
  async resolveShortUrl(shortUrl: string): Promise<string | null> {
    try {
      // First, follow the redirect chain
      let currentUrl = shortUrl
      let maxRedirects = 10

      while (maxRedirects > 0) {
        const response = await fetch(currentUrl, {
          redirect: "manual",
          headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
          },
        })

        if (response.status >= 300 && response.status < 400) {
          const location = response.headers.get("location")
          if (location) {
            currentUrl = location.startsWith("http") ? location : new URL(location, currentUrl).toString()
            maxRedirects--
            continue
          }
        }

        // If we got a final page, parse it for the actual link
        if (response.ok) {
          const html = await response.text()

          // Look for direct download links
          const directLinkMatch = html.match(/https?:\/\/[^"'\s]+\.(?:mp4|m3u8)[^"'\s]*/i)
          if (directLinkMatch) {
            return directLinkMatch[0]
          }

          // Look for embedded player source
          const sourceMatch = html.match(/source\s*[:=]\s*["']([^"']+\.(?:mp4|m3u8)[^"']*)["']/i)
          if (sourceMatch) {
            return sourceMatch[1]
          }

          // Look for file variable in JS
          const fileMatch = html.match(/file\s*[:=]\s*["']([^"']+)["']/i)
          if (fileMatch) {
            return fileMatch[1]
          }
        }

        break
      }

      return currentUrl !== shortUrl ? currentUrl : null
    } catch (error) {
      console.error("TPX URL resolve error:", error)
      return null
    }
  }

  // Get episode download links
  async getEpisodeLinks(episodeUrl: string): Promise<TPXEpisode | null> {
    try {
      const response = await fetch(episodeUrl, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        },
      })

      if (!response.ok) return null

      const html = await response.text()
      const parsedLinks = this.parseEpisodePage(html)

      // Extract episode number from URL
      const epMatch = episodeUrl.match(/episode-?(\d+)/i)
      const episodeNumber = epMatch ? Number.parseInt(epMatch[1]) : 1

      // Resolve all shortened URLs
      const resolvedLinks = await Promise.all(
        parsedLinks.map(async (link) => {
          const resolvedUrl = await this.resolveShortUrl(link.shortUrl)
          return {
            host: link.host,
            url: resolvedUrl || link.shortUrl,
          }
        }),
      )

      return {
        number: episodeNumber,
        links: resolvedLinks.filter((l) => l.url),
      }
    } catch (error) {
      console.error("TPX episode error:", error)
      return null
    }
  }

  // Search anime on TPX
  async search(query: string): Promise<{ title: string; url: string; poster?: string }[]> {
    try {
      const response = await fetch(`${this.baseUrl}/?s=${encodeURIComponent(query)}`, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        },
      })

      if (!response.ok) return []

      const html = await response.text()
      const results: { title: string; url: string; poster?: string }[] = []

      // Parse search results
      const itemRegex =
        /<article[^>]*>[\s\S]*?<a[^>]*href=["']([^"']+)["'][^>]*>[\s\S]*?<img[^>]*src=["']([^"']+)["'][^>]*>[\s\S]*?<h2[^>]*>([^<]+)<\/h2>/gi
      let match

      while ((match = itemRegex.exec(html)) !== null) {
        results.push({
          url: match[1],
          poster: match[2],
          title: match[3].trim(),
        })
      }

      return results
    } catch (error) {
      console.error("TPX search error:", error)
      return []
    }
  }

  // Get all episodes from anime page
  async getEpisodeList(animeUrl: string): Promise<string[]> {
    try {
      const response = await fetch(animeUrl, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        },
      })

      if (!response.ok) return []

      const html = await response.text()
      const episodes: string[] = []

      // Parse episode links
      const epRegex = /<a[^>]*href=["']([^"']*episode[^"']*)["'][^>]*>/gi
      let match

      while ((match = epRegex.exec(html)) !== null) {
        if (!episodes.includes(match[1])) {
          episodes.push(match[1])
        }
      }

      return episodes.sort((a, b) => {
        const numA = Number.parseInt(a.match(/episode-?(\d+)/i)?.[1] || "0")
        const numB = Number.parseInt(b.match(/episode-?(\d+)/i)?.[1] || "0")
        return numA - numB
      })
    } catch (error) {
      console.error("TPX episode list error:", error)
      return []
    }
  }
}

export const tpxsubAdapter = new TPXSubAdapter()
