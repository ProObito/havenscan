// HiAnime Source Adapter - API Based (Easiest)
// Uses public API for extraction

import type { Series, HiAnimeSearchResult, HiAnimeEpisode, HiAnimeSource } from "../types"

const HIANIME_API = process.env.HIANIME_API_URL || "https://api.consumet.org/anime/zoro"

export class HiAnimeAdapter {
  private baseUrl: string

  constructor() {
    this.baseUrl = HIANIME_API
  }

  // Search for anime
  async search(query: string, page = 1): Promise<HiAnimeSearchResult[]> {
    try {
      const response = await fetch(`${this.baseUrl}/${encodeURIComponent(query)}?page=${page}`)
      const data = await response.json()
      return data.results || []
    } catch (error) {
      console.error("HiAnime search error:", error)
      return []
    }
  }

  // Get anime details
  async getAnimeInfo(animeId: string): Promise<Partial<Series> | null> {
    try {
      const response = await fetch(`${this.baseUrl}/info?id=${animeId}`)
      const data = await response.json()

      return {
        title: data.title,
        poster: data.image,
        banner: data.cover,
        description: data.description,
        source: "hianime",
        sourceUrl: `https://hianime.to/${animeId}`,
        sourceId: animeId,
        type: "anime",
        status: data.status?.toLowerCase() === "ongoing" ? "ongoing" : "completed",
        language: ["Japanese"],
        genres: data.genres || [],
        year: data.releaseDate ? Number.parseInt(data.releaseDate) : undefined,
        rating: data.rating,
        totalEpisodes: data.totalEpisodes,
      }
    } catch (error) {
      console.error("HiAnime info error:", error)
      return null
    }
  }

  // Get episode list
  async getEpisodes(animeId: string): Promise<HiAnimeEpisode[]> {
    try {
      const response = await fetch(`${this.baseUrl}/info?id=${animeId}`)
      const data = await response.json()
      return data.episodes || []
    } catch (error) {
      console.error("HiAnime episodes error:", error)
      return []
    }
  }

  // Get streaming sources for an episode
  async getEpisodeSources(
    episodeId: string,
    server = "vidstreaming",
  ): Promise<{
    sources: HiAnimeSource[]
    subtitles: { url: string; lang: string }[]
  }> {
    try {
      const response = await fetch(`${this.baseUrl}/watch?episodeId=${episodeId}&server=${server}`)
      const data = await response.json()

      return {
        sources: data.sources || [],
        subtitles: data.subtitles || [],
      }
    } catch (error) {
      console.error("HiAnime sources error:", error)
      return { sources: [], subtitles: [] }
    }
  }

  // Get available servers for an episode
  async getServers(episodeId: string): Promise<{ name: string; url: string }[]> {
    try {
      const response = await fetch(`${this.baseUrl}/servers?episodeId=${episodeId}`)
      const data = await response.json()
      return data || []
    } catch (error) {
      console.error("HiAnime servers error:", error)
      return []
    }
  }

  // Extract M3U8 URL (for download)
  async extractM3U8(episodeId: string): Promise<string | null> {
    const { sources } = await this.getEpisodeSources(episodeId)

    // Prefer highest quality M3U8
    const m3u8Source =
      sources.find((s) => s.isM3U8 && s.quality === "1080p") ||
      sources.find((s) => s.isM3U8 && s.quality === "720p") ||
      sources.find((s) => s.isM3U8)

    return m3u8Source?.url || null
  }
}

export const hianimeAdapter = new HiAnimeAdapter()
