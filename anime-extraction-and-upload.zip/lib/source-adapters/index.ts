// Source Adapter Factory - Unified interface for all sources

import { hianimeAdapter, type HiAnimeAdapter } from "./hianime"
import { tpxsubAdapter, type TPXSubAdapter } from "./tpxsub"
import { desidubAdapter, type DesiDubAdapter } from "./desidub"
import type { Series } from "../types"

export type SourceType = "hianime" | "tpxsub" | "desidub"

export interface SearchResult {
  id: string
  title: string
  poster?: string
  url: string
  source: SourceType
}

export interface EpisodeResult {
  number: number
  streamUrl?: string
  downloadLinks?: { host: string; url: string }[]
  iframeUrl?: string
}

export class SourceAdapterFactory {
  private hianime: HiAnimeAdapter
  private tpxsub: TPXSubAdapter
  private desidub: DesiDubAdapter

  constructor() {
    this.hianime = hianimeAdapter
    this.tpxsub = tpxsubAdapter
    this.desidub = desidubAdapter
  }

  // Unified search across all sources
  async searchAll(query: string): Promise<SearchResult[]> {
    const results: SearchResult[] = []

    const [hianimeResults, tpxResults, desidubResults] = await Promise.allSettled([
      this.hianime.search(query),
      this.tpxsub.search(query),
      this.desidub.search(query),
    ])

    if (hianimeResults.status === "fulfilled") {
      results.push(
        ...hianimeResults.value.map((r) => ({
          id: r.id,
          title: r.title,
          poster: r.poster,
          url: `https://hianime.to/${r.id}`,
          source: "hianime" as SourceType,
        })),
      )
    }

    if (tpxResults.status === "fulfilled") {
      results.push(
        ...tpxResults.value.map((r) => ({
          id: encodeURIComponent(r.url),
          title: r.title,
          poster: r.poster,
          url: r.url,
          source: "tpxsub" as SourceType,
        })),
      )
    }

    if (desidubResults.status === "fulfilled") {
      results.push(
        ...desidubResults.value.map((r) => ({
          id: encodeURIComponent(r.url),
          title: r.title,
          poster: r.poster,
          url: r.url,
          source: "desidub" as SourceType,
        })),
      )
    }

    return results
  }

  // Search specific source
  async search(source: SourceType, query: string): Promise<SearchResult[]> {
    switch (source) {
      case "hianime": {
        const results = await this.hianime.search(query)
        return results.map((r) => ({
          id: r.id,
          title: r.title,
          poster: r.poster,
          url: `https://hianime.to/${r.id}`,
          source: "hianime",
        }))
      }
      case "tpxsub": {
        const results = await this.tpxsub.search(query)
        return results.map((r) => ({
          id: encodeURIComponent(r.url),
          title: r.title,
          poster: r.poster,
          url: r.url,
          source: "tpxsub",
        }))
      }
      case "desidub": {
        const results = await this.desidub.search(query)
        return results.map((r) => ({
          id: encodeURIComponent(r.url),
          title: r.title,
          poster: r.poster,
          url: r.url,
          source: "desidub",
        }))
      }
    }
  }

  // Get episode stream/download info
  async getEpisode(source: SourceType, episodeId: string, episodeUrl?: string): Promise<EpisodeResult | null> {
    switch (source) {
      case "hianime": {
        const sources = await this.hianime.getEpisodeSources(episodeId)
        const m3u8 = sources.sources.find((s) => s.isM3U8)
        return {
          number: Number.parseInt(episodeId.match(/-(\d+)$/)?.[1] || "1"),
          streamUrl: m3u8?.url,
          downloadLinks: sources.sources.map((s) => ({
            host: "HiAnime",
            url: s.url,
          })),
        }
      }
      case "tpxsub": {
        if (!episodeUrl) return null
        const episode = await this.tpxsub.getEpisodeLinks(episodeUrl)
        return episode
          ? {
              number: episode.number,
              downloadLinks: episode.links,
            }
          : null
      }
      case "desidub": {
        if (!episodeUrl) return null
        const episode = await this.desidub.getEpisodeStream(episodeUrl)
        return episode
          ? {
              number: episode.number,
              streamUrl: episode.streamUrl,
              iframeUrl: episode.iframeUrl,
            }
          : null
      }
    }
  }

  // Get anime info
  async getAnimeInfo(source: SourceType, animeId: string, animeUrl?: string): Promise<Partial<Series> | null> {
    switch (source) {
      case "hianime":
        return this.hianime.getAnimeInfo(animeId)
      case "tpxsub":
      case "desidub":
        if (!animeUrl) return null
        const info = await this.desidub.getAnimeInfo(animeUrl)
        return info
          ? {
              title: info.title,
              poster: info.poster,
              description: info.description,
              source,
              sourceUrl: animeUrl,
              sourceId: encodeURIComponent(animeUrl),
            }
          : null
    }
  }
}

export const sourceAdapter = new SourceAdapterFactory()
