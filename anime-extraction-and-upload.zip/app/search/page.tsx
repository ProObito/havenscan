"use client"

import type React from "react"

import { useState, useEffect, Suspense } from "react"
import { useSearchParams } from "next/navigation"
import { Header } from "@/components/header"
import { ThemeAnimations } from "@/components/theme-animations"
import { AnimeCard } from "@/components/anime-card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, SlidersHorizontal, Sparkles, X } from "lucide-react"
import type { Series } from "@/lib/types"

// Demo data for search results
const allAnime: Series[] = [
  {
    _id: "1",
    title: "Solo Leveling",
    slug: "solo-leveling",
    poster: "/solo-leveling-anime-poster.jpg",
    description: "In a world where hunters must battle deadly monsters...",
    source: "hianime",
    sourceUrl: "",
    sourceId: "solo-leveling",
    type: "anime",
    status: "ongoing",
    language: ["Japanese", "Hindi", "English"],
    genres: ["Action", "Fantasy", "Adventure"],
    year: 2024,
    rating: 8.9,
    totalEpisodes: 12,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: "2",
    title: "Demon Slayer",
    slug: "demon-slayer",
    poster: "/demon-slayer-poster.jpg",
    description: "Tanjiro becomes a demon slayer...",
    source: "hianime",
    sourceUrl: "",
    sourceId: "demon-slayer",
    type: "anime",
    status: "ongoing",
    language: ["Japanese", "Hindi"],
    genres: ["Action", "Supernatural"],
    year: 2019,
    rating: 8.7,
    totalEpisodes: 44,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: "3",
    title: "Jujutsu Kaisen",
    slug: "jujutsu-kaisen",
    poster: "/jujutsu-kaisen-poster.jpg",
    description: "A boy swallows a cursed talisman...",
    source: "hianime",
    sourceUrl: "",
    sourceId: "jujutsu-kaisen",
    type: "anime",
    status: "ongoing",
    language: ["Japanese", "English"],
    genres: ["Action", "Supernatural", "School"],
    year: 2020,
    rating: 8.6,
    totalEpisodes: 48,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: "4",
    title: "Soul Land",
    slug: "soul-land",
    poster: "/soul-land-donghua-poster.jpg",
    description: "Tang San spent his life in the Tang Outer Sect...",
    source: "desidub",
    sourceUrl: "",
    sourceId: "soul-land",
    type: "donghua",
    status: "ongoing",
    language: ["Chinese", "Hindi"],
    genres: ["Action", "Fantasy", "Romance"],
    year: 2018,
    rating: 8.3,
    totalEpisodes: 260,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
]

const genres = [
  "Action",
  "Adventure",
  "Comedy",
  "Drama",
  "Fantasy",
  "Horror",
  "Isekai",
  "Mecha",
  "Mystery",
  "Romance",
  "School",
  "Sci-Fi",
  "Slice of Life",
  "Sports",
  "Supernatural",
  "Thriller",
]

function SearchContent() {
  const searchParams = useSearchParams()
  const initialQuery = searchParams.get("q") || ""

  const [query, setQuery] = useState(initialQuery)
  const [results, setResults] = useState<Series[]>([])
  const [loading, setLoading] = useState(false)
  const [showFilters, setShowFilters] = useState(false)

  // Filters
  const [selectedType, setSelectedType] = useState<string>("all")
  const [selectedGenres, setSelectedGenres] = useState<string[]>([])
  const [selectedLanguage, setSelectedLanguage] = useState<string>("all")
  const [selectedYear, setSelectedYear] = useState<string>("all")

  // AI suggestions
  const [suggestions, setSuggestions] = useState<string[]>([
    "Best action anime 2024",
    "Hindi dubbed anime",
    "Donghua recommendations",
  ])

  useEffect(() => {
    if (initialQuery) {
      performSearch(initialQuery)
    }
  }, [initialQuery])

  const performSearch = async (searchQuery: string) => {
    setLoading(true)

    // Simulate fuzzy search with typo tolerance
    const normalizedQuery = searchQuery.toLowerCase()
    const filtered = allAnime.filter((anime) => {
      const titleMatch = anime.title.toLowerCase().includes(normalizedQuery)
      const genreMatch = anime.genres.some((g) => g.toLowerCase().includes(normalizedQuery))
      const descMatch = anime.description.toLowerCase().includes(normalizedQuery)

      // Type filter
      const typeMatch = selectedType === "all" || anime.type === selectedType

      // Genre filter
      const genresMatch = selectedGenres.length === 0 || selectedGenres.some((g) => anime.genres.includes(g))

      // Language filter
      const langMatch = selectedLanguage === "all" || anime.language.includes(selectedLanguage)

      return (titleMatch || genreMatch || descMatch) && typeMatch && genresMatch && langMatch
    })

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 300))

    setResults(filtered)
    setLoading(false)
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    performSearch(query)
  }

  const toggleGenre = (genre: string) => {
    setSelectedGenres((prev) => (prev.includes(genre) ? prev.filter((g) => g !== genre) : [...prev, genre]))
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ThemeAnimations />
      <Header />

      <div className="container mx-auto px-4 py-8">
        {/* Search Bar */}
        <form onSubmit={handleSearch} className="max-w-3xl mx-auto mb-8">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search anime, donghua, genres..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pl-12 pr-24 h-14 text-lg bg-card/50"
            />
            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-2">
              <Button
                type="button"
                variant="ghost"
                size="icon"
                onClick={() => setShowFilters(!showFilters)}
                className={showFilters ? "text-primary" : ""}
              >
                <SlidersHorizontal className="h-5 w-5" />
              </Button>
              <Button type="submit">Search</Button>
            </div>
          </div>
        </form>

        {/* AI Suggestions */}
        {!query && suggestions.length > 0 && (
          <div className="max-w-3xl mx-auto mb-8">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="h-4 w-4 text-primary" />
              <span className="text-sm text-muted-foreground">AI Suggestions</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {suggestions.map((suggestion) => (
                <Badge
                  key={suggestion}
                  variant="secondary"
                  className="cursor-pointer hover:bg-primary hover:text-primary-foreground transition-colors"
                  onClick={() => {
                    setQuery(suggestion)
                    performSearch(suggestion)
                  }}
                >
                  {suggestion}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Filters Panel */}
        {showFilters && (
          <Card className="max-w-3xl mx-auto mb-8">
            <CardContent className="pt-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Type</label>
                  <Select value={selectedType} onValueChange={setSelectedType}>
                    <SelectTrigger>
                      <SelectValue placeholder="All types" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="anime">Anime</SelectItem>
                      <SelectItem value="donghua">Donghua</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Language</label>
                  <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                    <SelectTrigger>
                      <SelectValue placeholder="All languages" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="Hindi">Hindi</SelectItem>
                      <SelectItem value="English">English</SelectItem>
                      <SelectItem value="Japanese">Japanese</SelectItem>
                      <SelectItem value="Tamil">Tamil</SelectItem>
                      <SelectItem value="Telugu">Telugu</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Year</label>
                  <Select value={selectedYear} onValueChange={setSelectedYear}>
                    <SelectTrigger>
                      <SelectValue placeholder="All years" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Years</SelectItem>
                      <SelectItem value="2024">2024</SelectItem>
                      <SelectItem value="2023">2023</SelectItem>
                      <SelectItem value="2022">2022</SelectItem>
                      <SelectItem value="2021">2021</SelectItem>
                      <SelectItem value="2020">2020</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Genre Tags */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Genres</label>
                <div className="flex flex-wrap gap-2">
                  {genres.map((genre) => (
                    <Badge
                      key={genre}
                      variant={selectedGenres.includes(genre) ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => toggleGenre(genre)}
                    >
                      {genre}
                      {selectedGenres.includes(genre) && <X className="h-3 w-3 ml-1" />}
                    </Badge>
                  ))}
                </div>
              </div>

              <Button variant="outline" className="w-full bg-transparent" onClick={() => performSearch(query)}>
                Apply Filters
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Results */}
        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="aspect-[2/3] bg-muted rounded-xl animate-pulse" />
            ))}
          </div>
        ) : results.length > 0 ? (
          <div>
            <p className="text-muted-foreground mb-4">
              Found {results.length} result{results.length !== 1 ? "s" : ""} for &quot;{query}&quot;
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {results.map((anime) => (
                <AnimeCard key={anime._id} anime={anime} />
              ))}
            </div>
          </div>
        ) : query ? (
          <Card className="max-w-md mx-auto">
            <CardContent className="pt-6 text-center space-y-4">
              <Search className="h-12 w-12 mx-auto text-muted-foreground" />
              <h2 className="text-xl font-semibold">No results found</h2>
              <p className="text-muted-foreground">Try different keywords or check the spelling</p>
            </CardContent>
          </Card>
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Enter a search term to find anime and donghua</p>
          </div>
        )}
      </div>
    </div>
  )
}

export default function SearchPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-background flex items-center justify-center">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
        </div>
      }
    >
      <SearchContent />
    </Suspense>
  )
}
