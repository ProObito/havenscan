"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Header } from "@/components/header"
import { ThemeAnimations } from "@/components/theme-animations"
import { AnimeCard } from "@/components/anime-card"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Search, Share2, Trash2, BookmarkX, LogIn } from "lucide-react"
import type { Series } from "@/lib/types"

// Demo watchlist data
const demoWatchlist: Series[] = [
  {
    _id: "1",
    title: "Solo Leveling",
    slug: "solo-leveling",
    poster: "/solo-leveling-anime-poster.jpg",
    description: "In a world where hunters must battle deadly monsters...",
    source: "hianime",
    sourceUrl: "",
    sourceId: "solo-leveling",
    type: "anime",
    status: "ongoing",
    language: ["Japanese", "Hindi"],
    genres: ["Action", "Fantasy"],
    year: 2024,
    rating: 8.9,
    totalEpisodes: 12,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: "2",
    title: "Demon Slayer",
    slug: "demon-slayer",
    poster: "/demon-slayer-poster.jpg",
    description: "Tanjiro becomes a demon slayer after his family is killed...",
    source: "hianime",
    sourceUrl: "",
    sourceId: "demon-slayer",
    type: "anime",
    status: "ongoing",
    language: ["Japanese", "Hindi", "English"],
    genres: ["Action", "Supernatural"],
    year: 2019,
    rating: 8.7,
    totalEpisodes: 44,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
]

export default function WatchlistPage() {
  const { user } = useAuth()
  const [watchlist, setWatchlist] = useState<Series[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [shareUrl, setShareUrl] = useState("")

  useEffect(() => {
    // In production, fetch from API
    if (user) {
      setWatchlist(demoWatchlist)
      setShareUrl(`${window.location.origin}/watchlist/share/${user._id}`)
    }
  }, [user])

  const filteredList = watchlist.filter(
    (anime) =>
      anime.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      anime.genres.some((g) => g.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  const handleRemove = (id: string) => {
    setWatchlist(watchlist.filter((a) => a._id !== id))
  }

  const handleShare = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl)
      alert("Watchlist link copied to clipboard!")
    } catch {
      alert("Failed to copy link")
    }
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <ThemeAnimations />
        <Header />

        <div className="container mx-auto px-4 py-16">
          <Card className="max-w-md mx-auto">
            <CardContent className="pt-6 text-center space-y-4">
              <LogIn className="h-12 w-12 mx-auto text-muted-foreground" />
              <h2 className="text-xl font-semibold">Login Required</h2>
              <p className="text-muted-foreground">Please login to access your watchlist</p>
              <Button asChild>
                <Link href="/login">Login</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ThemeAnimations />
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold">My Watchlist</h1>
            <p className="text-muted-foreground">{watchlist.length} items saved</p>
          </div>

          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search watchlist..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
            <Button variant="outline" className="gap-2 bg-transparent" onClick={handleShare}>
              <Share2 className="h-4 w-4" />
              Share List
            </Button>
          </div>
        </div>

        <Tabs defaultValue="all">
          <TabsList>
            <TabsTrigger value="all">All ({watchlist.length})</TabsTrigger>
            <TabsTrigger value="watching">Watching</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
            <TabsTrigger value="plan">Plan to Watch</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="mt-6">
            {filteredList.length === 0 ? (
              <Card className="max-w-md mx-auto">
                <CardContent className="pt-6 text-center space-y-4">
                  <BookmarkX className="h-12 w-12 mx-auto text-muted-foreground" />
                  <h2 className="text-xl font-semibold">No items found</h2>
                  <p className="text-muted-foreground">
                    {searchQuery ? "Try a different search term" : "Start adding anime to your watchlist!"}
                  </p>
                  <Button asChild>
                    <Link href="/">Browse Anime</Link>
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {filteredList.map((anime) => (
                  <div key={anime._id} className="relative group">
                    <AnimeCard anime={anime} isInWatchlist onAddToWatchlist={() => handleRemove(anime._id || "")} />
                    <Button
                      variant="destructive"
                      size="icon"
                      className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8"
                      onClick={() => handleRemove(anime._id || "")}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="watching" className="mt-6">
            <p className="text-center text-muted-foreground py-8">No anime in this category</p>
          </TabsContent>

          <TabsContent value="completed" className="mt-6">
            <p className="text-center text-muted-foreground py-8">No anime in this category</p>
          </TabsContent>

          <TabsContent value="plan" className="mt-6">
            <p className="text-center text-muted-foreground py-8">No anime in this category</p>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
