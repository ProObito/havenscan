"use client"

import { useState } from "react"
import Link from "next/link"
import { Header } from "@/components/header"
import { ThemeAnimations } from "@/components/theme-animations"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, Crown, Download, Zap, Shield, Star, Sparkles } from "lucide-react"
import { cn } from "@/lib/utils"

const plans = [
  {
    id: "monthly",
    name: "Monthly",
    price: 99,
    currency: "INR",
    period: "/month",
    description: "Perfect for trying out premium features",
    features: ["Unlimited downloads", "HD & 4K quality", "No ads", "Priority support", "Early access to new releases"],
    popular: false,
  },
  {
    id: "yearly",
    name: "Yearly",
    price: 799,
    currency: "INR",
    period: "/year",
    description: "Best value - Save 33%!",
    features: [
      "Everything in Monthly",
      "2 months free",
      "Exclusive premium badge",
      "Offline viewing",
      "Request anime/donghua",
    ],
    popular: true,
  },
  {
    id: "lifetime",
    name: "Lifetime",
    price: 1999,
    currency: "INR",
    period: "one-time",
    description: "Pay once, enjoy forever",
    features: [
      "Everything in Yearly",
      "Lifetime access",
      "VIP support",
      "Beta features access",
      "Special collector badge",
    ],
    popular: false,
  },
]

const features = [
  {
    icon: Download,
    title: "Unlimited Downloads",
    description: "Download any episode to watch offline on your device",
  },
  {
    icon: Zap,
    title: "HD & 4K Quality",
    description: "Stream and download in the highest quality available",
  },
  {
    icon: Shield,
    title: "No Advertisements",
    description: "Enjoy uninterrupted viewing without any ads",
  },
  {
    icon: Star,
    title: "Early Access",
    description: "Get new episodes before everyone else",
  },
]

export default function PremiumPage() {
  const { user, isPremium, updateProfile } = useAuth()
  const [selectedPlan, setSelectedPlan] = useState("yearly")
  const [loading, setLoading] = useState(false)

  const handleSubscribe = async (planId: string) => {
    if (!user) {
      window.location.href = "/login"
      return
    }

    setLoading(true)
    // In production, integrate with Stripe/Razorpay
    // For demo, just update user role
    await updateProfile({ role: "premium", premiumExpiry: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000) })
    setLoading(false)
  }

  if (isPremium) {
    return (
      <div className="min-h-screen bg-background text-foreground">
        <ThemeAnimations />
        <Header />

        <div className="container mx-auto px-4 py-16 text-center">
          <div className="max-w-md mx-auto space-y-6">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-yellow-500/20">
              <Crown className="h-10 w-10 text-yellow-500" />
            </div>
            <h1 className="text-3xl font-bold">You&apos;re Premium!</h1>
            <p className="text-muted-foreground">
              Thank you for supporting AniCrew. Enjoy unlimited downloads and premium features!
            </p>
            <div className="flex items-center justify-center gap-2">
              <Badge className="bg-yellow-500 text-black gap-1">
                <Crown className="h-3 w-3" />
                Premium Member
              </Badge>
            </div>
            <Button asChild>
              <Link href="/">Start Watching</Link>
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ThemeAnimations />
      <Header />

      {/* Hero Section */}
      <section className="relative py-16 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent" />
        <div className="container mx-auto px-4 relative">
          <div className="text-center max-w-2xl mx-auto space-y-4">
            <Badge className="bg-yellow-500/20 text-yellow-500 gap-1">
              <Sparkles className="h-3 w-3" />
              Premium
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold">Unlock the Full Experience</h1>
            <p className="text-lg text-muted-foreground">
              Download episodes, watch in HD/4K, and enjoy ad-free streaming with AniCrew Premium
            </p>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature) => (
            <Card key={feature.title} className="bg-card/50 border-border/50">
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center space-y-3">
                  <div className="p-3 rounded-full bg-primary/10">
                    <feature.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-semibold">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Pricing Plans */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-2xl font-bold text-center mb-8">Choose Your Plan</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {plans.map((plan) => (
            <Card
              key={plan.id}
              className={cn(
                "relative transition-all",
                selectedPlan === plan.id
                  ? "border-primary ring-2 ring-primary/20"
                  : "border-border/50 hover:border-primary/50",
                plan.popular && "scale-105 shadow-xl",
              )}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <Badge className="bg-primary">Most Popular</Badge>
                </div>
              )}
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {plan.name}
                  {plan.id === "lifetime" && <Crown className="h-5 w-5 text-yellow-500" />}
                </CardTitle>
                <CardDescription>{plan.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-baseline gap-1">
                  <span className="text-sm text-muted-foreground">{plan.currency}</span>
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-muted-foreground">{plan.period}</span>
                </div>
                <ul className="space-y-2">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm">
                      <Check className="h-4 w-4 text-primary" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <Button
                  className="w-full"
                  variant={selectedPlan === plan.id ? "default" : "outline"}
                  onClick={() => {
                    setSelectedPlan(plan.id)
                    handleSubscribe(plan.id)
                  }}
                  disabled={loading}
                >
                  {loading ? "Processing..." : "Get Started"}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="container mx-auto px-4 py-16 border-t border-border/40">
        <h2 className="text-2xl font-bold text-center mb-8">Frequently Asked Questions</h2>
        <div className="max-w-2xl mx-auto space-y-4">
          <Card className="bg-card/50">
            <CardHeader>
              <CardTitle className="text-lg">How does the download feature work?</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Premium members can download episodes directly from the watch page. Downloads are available in multiple
                qualities and can be watched offline.
              </p>
            </CardContent>
          </Card>
          <Card className="bg-card/50">
            <CardHeader>
              <CardTitle className="text-lg">Can I cancel my subscription?</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Yes, you can cancel anytime. Your premium benefits will remain active until the end of your billing
                period.
              </p>
            </CardContent>
          </Card>
          <Card className="bg-card/50">
            <CardHeader>
              <CardTitle className="text-lg">What payment methods are accepted?</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We accept all major credit/debit cards, UPI, net banking, and popular wallets through Razorpay.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}
