"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { ThemeAnimations } from "@/components/theme-animations"
import { AnimeCard } from "@/components/anime-card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter } from "lucide-react"
import type { Series } from "@/lib/types"

const demoDonghuaList: Series[] = [
  {
    _id: "1",
    title: "Soul Land",
    slug: "soul-land",
    poster: "/soul-land-donghua-poster.jpg",
    description: "Tang San spent his life in the Tang Outer Sect...",
    source: "desidub",
    sourceUrl: "",
    sourceId: "soul-land",
    type: "donghua",
    status: "ongoing",
    language: ["Chinese", "Hindi"],
    genres: ["Action", "Fantasy", "Romance"],
    year: 2018,
    rating: 8.3,
    totalEpisodes: 260,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: "2",
    title: "Battle Through the Heavens",
    slug: "battle-through-the-heavens",
    poster: "/battle-through-heavens-donghua-poster.jpg",
    description: "In a land where there is no magic...",
    source: "desidub",
    sourceUrl: "",
    sourceId: "btth",
    type: "donghua",
    status: "ongoing",
    language: ["Chinese", "Hindi", "English"],
    genres: ["Action", "Fantasy", "Martial Arts"],
    year: 2017,
    rating: 8.1,
    totalEpisodes: 52,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: "3",
    title: "The King's Avatar",
    slug: "the-kings-avatar",
    poster: "/kings-avatar-donghua-poster.jpg",
    description: "A legendary esports player makes a comeback...",
    source: "desidub",
    sourceUrl: "",
    sourceId: "kings-avatar",
    type: "donghua",
    status: "completed",
    language: ["Chinese", "English"],
    genres: ["Action", "Sports", "Gaming"],
    year: 2017,
    rating: 8.5,
    totalEpisodes: 12,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: "4",
    title: "Martial Universe",
    slug: "martial-universe",
    poster: "/martial-universe-donghua-poster.jpg",
    description: "A young boy from a small clan gains power...",
    source: "desidub",
    sourceUrl: "",
    sourceId: "martial-universe",
    type: "donghua",
    status: "ongoing",
    language: ["Chinese", "Hindi"],
    genres: ["Action", "Fantasy", "Martial Arts"],
    year: 2019,
    rating: 7.9,
    totalEpisodes: 52,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
]

const genres = ["Action", "Adventure", "Fantasy", "Martial Arts", "Romance", "Comedy", "Sports"]

export default function DonghuaPage() {
  const [donghuaList] = useState<Series[]>(demoDonghuaList)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedGenre, setSelectedGenre] = useState<string>("all")
  const [sortBy, setSortBy] = useState<string>("latest")

  const filteredDonghua = donghuaList
    .filter((donghua) => {
      const matchesSearch = donghua.title.toLowerCase().includes(searchQuery.toLowerCase())
      const matchesGenre = selectedGenre === "all" || donghua.genres.includes(selectedGenre)
      return matchesSearch && matchesGenre
    })
    .sort((a, b) => {
      if (sortBy === "rating") return (b.rating || 0) - (a.rating || 0)
      if (sortBy === "year") return (b.year || 0) - (a.year || 0)
      return 0
    })

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ThemeAnimations />
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold">Donghua</h1>
            <p className="text-muted-foreground">{filteredDonghua.length} Chinese animations available</p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 md:flex-none">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-full md:w-48"
              />
            </div>

            <Select value={selectedGenre} onValueChange={setSelectedGenre}>
              <SelectTrigger className="w-32">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Genre" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Genres</SelectItem>
                {genres.map((genre) => (
                  <SelectItem key={genre} value={genre}>
                    {genre}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Sort" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="latest">Latest</SelectItem>
                <SelectItem value="rating">Rating</SelectItem>
                <SelectItem value="year">Year</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Genre Tags */}
        <div className="flex flex-wrap gap-2 mb-6">
          <Badge
            variant={selectedGenre === "all" ? "default" : "outline"}
            className="cursor-pointer"
            onClick={() => setSelectedGenre("all")}
          >
            All
          </Badge>
          {genres.map((genre) => (
            <Badge
              key={genre}
              variant={selectedGenre === genre ? "default" : "outline"}
              className="cursor-pointer"
              onClick={() => setSelectedGenre(genre)}
            >
              {genre}
            </Badge>
          ))}
        </div>

        {/* Donghua Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {filteredDonghua.map((donghua) => (
            <AnimeCard key={donghua._id} anime={donghua} />
          ))}
        </div>

        {filteredDonghua.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No donghua found matching your criteria</p>
          </div>
        )}
      </div>
    </div>
  )
}
