"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { ThemeAnimations } from "@/components/theme-animations"
import { AnimeCard } from "@/components/anime-card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Filter, LayoutGrid, List } from "lucide-react"
import type { Series } from "@/lib/types"

const demoAnimeList: Series[] = [
  {
    _id: "1",
    title: "Solo Leveling",
    slug: "solo-leveling",
    poster: "/solo-leveling-anime-poster.jpg",
    description: "In a world where hunters must battle deadly monsters...",
    source: "hianime",
    sourceUrl: "",
    sourceId: "solo-leveling",
    type: "anime",
    status: "ongoing",
    language: ["Japanese", "Hindi", "English"],
    genres: ["Action", "Fantasy", "Adventure"],
    year: 2024,
    rating: 8.9,
    totalEpisodes: 12,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: "2",
    title: "Demon Slayer",
    slug: "demon-slayer",
    poster: "/demon-slayer-poster.jpg",
    description: "Tanjiro becomes a demon slayer...",
    source: "hianime",
    sourceUrl: "",
    sourceId: "demon-slayer",
    type: "anime",
    status: "ongoing",
    language: ["Japanese", "Hindi"],
    genres: ["Action", "Supernatural"],
    year: 2019,
    rating: 8.7,
    totalEpisodes: 44,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: "3",
    title: "Jujutsu Kaisen",
    slug: "jujutsu-kaisen",
    poster: "/jujutsu-kaisen-poster.jpg",
    description: "A boy swallows a cursed talisman...",
    source: "hianime",
    sourceUrl: "",
    sourceId: "jujutsu-kaisen",
    type: "anime",
    status: "ongoing",
    language: ["Japanese", "English"],
    genres: ["Action", "Supernatural", "School"],
    year: 2020,
    rating: 8.6,
    totalEpisodes: 48,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: "4",
    title: "Attack on Titan",
    slug: "attack-on-titan",
    poster: "/attack-on-titan-inspired-poster.png",
    description: "Humanity lives inside cities surrounded by walls...",
    source: "hianime",
    sourceUrl: "",
    sourceId: "attack-on-titan",
    type: "anime",
    status: "completed",
    language: ["Japanese", "Hindi", "English", "Tamil"],
    genres: ["Action", "Drama", "Military"],
    year: 2013,
    rating: 9.0,
    totalEpisodes: 87,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: "5",
    title: "One Punch Man",
    slug: "one-punch-man",
    poster: "/one-punch-man-poster.jpg",
    description: "Saitama is a hero who can defeat any opponent with one punch...",
    source: "hianime",
    sourceUrl: "",
    sourceId: "one-punch-man",
    type: "anime",
    status: "ongoing",
    language: ["Japanese", "Hindi"],
    genres: ["Action", "Comedy", "Parody"],
    year: 2015,
    rating: 8.8,
    totalEpisodes: 24,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: "6",
    title: "My Hero Academia",
    slug: "my-hero-academia",
    poster: "/my-hero-academia-poster.jpg",
    description: "In a world of superheroes, Izuku Midoriya dreams of becoming one...",
    source: "hianime",
    sourceUrl: "",
    sourceId: "my-hero-academia",
    type: "anime",
    status: "ongoing",
    language: ["Japanese", "English"],
    genres: ["Action", "School", "Superhero"],
    year: 2016,
    rating: 8.4,
    totalEpisodes: 138,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
]

const genres = ["Action", "Adventure", "Comedy", "Drama", "Fantasy", "Horror", "Romance", "Sci-Fi", "Supernatural"]

export default function AnimePage() {
  const [animeList] = useState<Series[]>(demoAnimeList)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedGenre, setSelectedGenre] = useState<string>("all")
  const [sortBy, setSortBy] = useState<string>("latest")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")

  const filteredAnime = animeList
    .filter((anime) => {
      const matchesSearch = anime.title.toLowerCase().includes(searchQuery.toLowerCase())
      const matchesGenre = selectedGenre === "all" || anime.genres.includes(selectedGenre)
      return matchesSearch && matchesGenre
    })
    .sort((a, b) => {
      if (sortBy === "rating") return (b.rating || 0) - (a.rating || 0)
      if (sortBy === "year") return (b.year || 0) - (a.year || 0)
      return 0 // latest - default order
    })

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ThemeAnimations />
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold">Anime</h1>
            <p className="text-muted-foreground">{filteredAnime.length} titles available</p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 md:flex-none">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-full md:w-48"
              />
            </div>

            <Select value={selectedGenre} onValueChange={setSelectedGenre}>
              <SelectTrigger className="w-32">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Genre" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Genres</SelectItem>
                {genres.map((genre) => (
                  <SelectItem key={genre} value={genre}>
                    {genre}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Sort" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="latest">Latest</SelectItem>
                <SelectItem value="rating">Rating</SelectItem>
                <SelectItem value="year">Year</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex border rounded-md">
              <Button
                variant={viewMode === "grid" ? "secondary" : "ghost"}
                size="icon"
                onClick={() => setViewMode("grid")}
              >
                <LayoutGrid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === "list" ? "secondary" : "ghost"}
                size="icon"
                onClick={() => setViewMode("list")}
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Genre Tags */}
        <div className="flex flex-wrap gap-2 mb-6">
          <Badge
            variant={selectedGenre === "all" ? "default" : "outline"}
            className="cursor-pointer"
            onClick={() => setSelectedGenre("all")}
          >
            All
          </Badge>
          {genres.map((genre) => (
            <Badge
              key={genre}
              variant={selectedGenre === genre ? "default" : "outline"}
              className="cursor-pointer"
              onClick={() => setSelectedGenre(genre)}
            >
              {genre}
            </Badge>
          ))}
        </div>

        {/* Anime Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {filteredAnime.map((anime) => (
            <AnimeCard key={anime._id} anime={anime} />
          ))}
        </div>

        {filteredAnime.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No anime found matching your criteria</p>
          </div>
        )}
      </div>
    </div>
  )
}
