"use client"

import { useState } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { Header } from "@/components/header"
import { ThemeAnimations } from "@/components/theme-animations"
import { CommentSection } from "@/components/comment-section"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Play, Plus, Share2, Star, Calendar, Clock, Film, Check, Lock, Crown, Download } from "lucide-react"
import type { Series, Episode } from "@/lib/types"

// Demo data
const demoSeries: Series = {
  _id: "1",
  title: "Solo Leveling",
  slug: "solo-leveling",
  poster: "/solo-leveling-anime-poster.jpg",
  banner: "/solo-leveling-anime-banner.jpg",
  description:
    "In a world where hunters must battle deadly monsters to protect humanity, Sung Jin-woo, the weakest hunter in humanity, faces a deadly situation in a double dungeon. When all seems lost, he receives a mysterious power to level up.",
  source: "hianime",
  sourceUrl: "",
  sourceId: "solo-leveling",
  type: "anime",
  status: "ongoing",
  language: ["Japanese", "Hindi", "English", "Tamil"],
  genres: ["Action", "Fantasy", "Adventure", "Supernatural"],
  year: 2024,
  rating: 8.9,
  totalEpisodes: 12,
  createdAt: new Date(),
  updatedAt: new Date(),
}

const demoEpisodes: Episode[] = Array.from({ length: 12 }, (_, i) => ({
  _id: `ep-${i + 1}`,
  seriesId: "1",
  episodeNumber: i + 1,
  title: `Episode ${i + 1}`,
  thumbnail: `/placeholder.svg?height=120&width=200&query=solo leveling episode ${i + 1}`,
  duration: 24,
  status: "uploaded",
  languages: [
    { audio: "Japanese", subtitle: "English", streamUrl: "" },
    { audio: "Hindi", streamUrl: "" },
    { audio: "Tamil", streamUrl: "" },
  ],
  retries: 0,
  createdAt: new Date(),
  updatedAt: new Date(),
}))

export default function AnimePage() {
  const params = useParams()
  const { user, isPremium } = useAuth()
  const [series] = useState<Series>(demoSeries)
  const [episodes] = useState<Episode[]>(demoEpisodes)
  const [selectedLanguage, setSelectedLanguage] = useState("Japanese")
  const [inWatchlist, setInWatchlist] = useState(false)

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ThemeAnimations />
      <Header />

      {/* Banner Section */}
      <section className="relative h-[50vh] min-h-[400px] overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${series.banner || series.poster})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-background/30" />
      </section>

      {/* Content Section */}
      <div className="container mx-auto px-4 -mt-48 relative z-10">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Poster */}
          <div className="flex-shrink-0">
            <div className="relative w-48 md:w-64 aspect-[2/3] rounded-xl overflow-hidden shadow-2xl">
              <Image src={series.poster || "/placeholder.svg"} alt={series.title} fill className="object-cover" />
            </div>
          </div>

          {/* Info */}
          <div className="flex-1 space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="secondary" className="bg-primary text-primary-foreground">
                {series.type === "donghua" ? "Donghua" : "Anime"}
              </Badge>
              <Badge variant="outline" className="capitalize">
                {series.status}
              </Badge>
              {series.rating && (
                <Badge variant="secondary" className="bg-yellow-500/90 text-black gap-1">
                  <Star className="h-3 w-3 fill-current" />
                  {series.rating}
                </Badge>
              )}
            </div>

            <h1 className="text-3xl md:text-4xl font-bold text-balance">{series.title}</h1>

            <p className="text-foreground/80 leading-relaxed">{series.description}</p>

            <div className="flex flex-wrap gap-2">
              {series.genres.map((genre) => (
                <Badge key={genre} variant="outline">
                  {genre}
                </Badge>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <Calendar className="h-4 w-4" />
                {series.year}
              </span>
              <span className="flex items-center gap-1">
                <Film className="h-4 w-4" />
                {series.totalEpisodes} Episodes
              </span>
              <span className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                ~24 min
              </span>
            </div>

            {/* Language Selector */}
            <div className="flex items-center gap-3">
              <span className="text-sm text-muted-foreground">Audio:</span>
              <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {series.language.map((lang) => (
                    <SelectItem key={lang} value={lang}>
                      {lang}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <Button size="lg" className="gap-2" asChild>
                <Link href={`/watch/${series.slug}?ep=1`}>
                  <Play className="h-5 w-5 fill-current" />
                  Watch Now
                </Link>
              </Button>
              <Button
                size="lg"
                variant={inWatchlist ? "secondary" : "outline"}
                className="gap-2"
                onClick={() => setInWatchlist(!inWatchlist)}
              >
                {inWatchlist ? <Check className="h-5 w-5" /> : <Plus className="h-5 w-5" />}
                {inWatchlist ? "In Watchlist" : "Add to List"}
              </Button>
              <Button size="lg" variant="outline" className="gap-2 bg-transparent">
                <Share2 className="h-5 w-5" />
                Share
              </Button>
            </div>
          </div>
        </div>

        {/* Episodes & Comments Tabs */}
        <Tabs defaultValue="episodes" className="mt-12">
          <TabsList>
            <TabsTrigger value="episodes">Episodes</TabsTrigger>
            <TabsTrigger value="comments">Comments</TabsTrigger>
          </TabsList>

          <TabsContent value="episodes" className="mt-6">
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {episodes.map((ep) => (
                <Link key={ep._id} href={`/watch/${series.slug}?ep=${ep.episodeNumber}`}>
                  <Card className="overflow-hidden hover:ring-2 hover:ring-primary transition-all group">
                    <div className="relative aspect-video">
                      <Image
                        src={ep.thumbnail || "/placeholder.svg?height=120&width=200&query=anime episode thumbnail"}
                        alt={ep.title}
                        fill
                        className="object-cover"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Play className="h-10 w-10 text-white fill-white" />
                      </div>
                    </div>
                    <CardContent className="p-3">
                      <p className="font-medium text-sm">Episode {ep.episodeNumber}</p>
                      <p className="text-xs text-muted-foreground">{ep.duration} min</p>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="comments" className="mt-6">
            <CommentSection seriesId={series._id || ""} />
          </TabsContent>
        </Tabs>

        {/* Download Section */}
        <div className="mt-12 mb-8">
          <Card className="bg-card/50 border-primary/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={isPremium ? "p-3 rounded-full bg-yellow-500/10" : "p-3 rounded-full bg-muted"}>
                    {isPremium ? (
                      <Crown className="h-6 w-6 text-yellow-500" />
                    ) : (
                      <Lock className="h-6 w-6 text-muted-foreground" />
                    )}
                  </div>
                  <div>
                    <h3 className="font-semibold">{isPremium ? "Download Available" : "Download Locked"}</h3>
                    <p className="text-sm text-muted-foreground">
                      {isPremium
                        ? "You can download all episodes as a premium member"
                        : "Upgrade to premium to download episodes"}
                    </p>
                  </div>
                </div>
                {isPremium ? (
                  <Button className="gap-2">
                    <Download className="h-4 w-4" />
                    Download All
                  </Button>
                ) : (
                  <Button variant="outline" className="gap-2 text-yellow-500 border-yellow-500 bg-transparent" asChild>
                    <Link href="/premium">
                      <Crown className="h-4 w-4" />
                      Go Premium
                    </Link>
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
