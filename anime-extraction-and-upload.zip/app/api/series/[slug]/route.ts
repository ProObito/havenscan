// API Route: Single series operations

import { type NextRequest, NextResponse } from "next/server"
import { getSeriesCollection, getEpisodesCollection } from "@/lib/db"

// GET - Get series by slug with episodes
export async function GET(request: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params

  try {
    const seriesCollection = await getSeriesCollection()
    const episodesCollection = await getEpisodesCollection()

    const series = await seriesCollection.findOne({ slug })

    if (!series) {
      return NextResponse.json({ error: "Series not found" }, { status: 404 })
    }

    const episodes = await episodesCollection
      .find({ seriesId: series._id?.toString() })
      .sort({ episodeNumber: 1 })
      .toArray()

    return NextResponse.json({
      series,
      episodes,
    })
  } catch (error) {
    console.error("Series fetch error:", error)
    return NextResponse.json({ error: "Failed to fetch series" }, { status: 500 })
  }
}

// PATCH - Update series
export async function PATCH(request: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params

  try {
    const body = await request.json()
    const series = await getSeriesCollection()

    const result = await series.updateOne(
      { slug },
      {
        $set: {
          ...body,
          updatedAt: new Date(),
        },
      },
    )

    if (result.matchedCount === 0) {
      return NextResponse.json({ error: "Series not found" }, { status: 404 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Series update error:", error)
    return NextResponse.json({ error: "Failed to update series" }, { status: 500 })
  }
}

// DELETE - Delete series and episodes
export async function DELETE(request: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params

  try {
    const seriesCollection = await getSeriesCollection()
    const episodesCollection = await getEpisodesCollection()

    const series = await seriesCollection.findOne({ slug })

    if (!series) {
      return NextResponse.json({ error: "Series not found" }, { status: 404 })
    }

    // Delete all episodes
    await episodesCollection.deleteMany({ seriesId: series._id?.toString() })

    // Delete series
    await seriesCollection.deleteOne({ slug })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Series delete error:", error)
    return NextResponse.json({ error: "Failed to delete series" }, { status: 500 })
  }
}
