// API Route: Series CRUD operations

import { type NextRequest, NextResponse } from "next/server"
import { getSeriesCollection } from "@/lib/db"

// GET - List all series or search
export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const query = searchParams.get("q")
  const type = searchParams.get("type")
  const genre = searchParams.get("genre")
  const page = Number.parseInt(searchParams.get("page") || "1")
  const limit = Number.parseInt(searchParams.get("limit") || "20")

  try {
    const series = await getSeriesCollection()

    const filter: Record<string, unknown> = {}

    if (query) {
      filter.$text = { $search: query }
    }
    if (type && (type === "anime" || type === "donghua")) {
      filter.type = type
    }
    if (genre) {
      filter.genres = genre
    }

    const [results, total] = await Promise.all([
      series
        .find(filter)
        .sort({ updatedAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit)
        .toArray(),
      series.countDocuments(filter),
    ])

    return NextResponse.json({
      results,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error("Series list error:", error)
    return NextResponse.json({ error: "Failed to fetch series" }, { status: 500 })
  }
}

// POST - Create new series manually
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { title, type, description, poster, genres, language } = body

    if (!title) {
      return NextResponse.json({ error: "Title is required" }, { status: 400 })
    }

    const series = await getSeriesCollection()

    const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, "-")

    // Check if slug exists
    const existing = await series.findOne({ slug })
    if (existing) {
      return NextResponse.json({ error: "Series with this title already exists" }, { status: 409 })
    }

    const newSeries = {
      title,
      slug,
      poster: poster || "",
      description: description || "",
      source: "manual" as const,
      sourceUrl: "",
      sourceId: slug,
      type: type || "anime",
      status: "ongoing" as const,
      language: language || ["Japanese"],
      genres: genres || [],
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    const result = await series.insertOne(newSeries as any)

    return NextResponse.json({
      success: true,
      id: result.insertedId.toString(),
      series: { ...newSeries, _id: result.insertedId.toString() },
    })
  } catch (error) {
    console.error("Series create error:", error)
    return NextResponse.json({ error: "Failed to create series" }, { status: 500 })
  }
}
