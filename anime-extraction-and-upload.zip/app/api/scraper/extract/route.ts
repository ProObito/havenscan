// API Route: Extract and queue episode for processing

import { type NextRequest, NextResponse } from "next/server"
import { getSeriesCollection, getEpisodesCollection } from "@/lib/db"
import { sourceAdapter } from "@/lib/source-adapters"
import { downloadQueue } from "@/lib/download-queue"
import type { Series, Episode } from "@/lib/types"
import { ObjectId } from "mongodb"

export async function POST(request: NextRequest) {
  try {
    await downloadQueue.initialize()

    const body = await request.json()
    const { source, animeId, animeUrl, episodeNumbers } = body

    if (!source || !animeId) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    console.log(`[Extract] Starting extraction for ${source}/${animeId}`)

    const seriesCollection = await getSeriesCollection()
    const episodesCollection = await getEpisodesCollection()

    // Get or create series
    let series = await seriesCollection.findOne({ sourceId: animeId, source })

    if (!series) {
      // Fetch anime info
      console.log(`[Extract] Fetching anime info for ${animeId}`)
      const animeInfo = await sourceAdapter.getAnimeInfo(source, animeId, animeUrl)

      if (!animeInfo) {
        return NextResponse.json({ error: "Failed to fetch anime info" }, { status: 404 })
      }

      const newSeries: Series = {
        title: animeInfo.title || "Unknown",
        slug: (animeInfo.title || "unknown").toLowerCase().replace(/[^a-z0-9]+/g, "-"),
        poster: animeInfo.poster || "",
        banner: animeInfo.banner,
        description: animeInfo.description || "",
        source,
        sourceUrl: animeInfo.sourceUrl || animeUrl || "",
        sourceId: animeId,
        type: "anime",
        status: animeInfo.status || "ongoing",
        language: animeInfo.language || ["Japanese"],
        genres: animeInfo.genres || [],
        year: animeInfo.year,
        rating: animeInfo.rating,
        totalEpisodes: animeInfo.totalEpisodes,
        createdAt: new Date(),
        updatedAt: new Date(),
      }

      const result = await seriesCollection.insertOne(newSeries as any)
      series = { ...newSeries, _id: result.insertedId.toString() }
      console.log(`[Extract] Created new series: ${series.title}`)
    }

    // Create episode records and queue for processing
    const queuedEpisodes: string[] = []
    const skippedEpisodes: number[] = []

    const epsToProcess = episodeNumbers || [1]
    console.log(`[Extract] Processing ${epsToProcess.length} episodes`)

    for (const epNum of epsToProcess) {
      // Check if episode already exists
      const existingEp = await episodesCollection.findOne({
        seriesId: series._id?.toString(),
        episodeNumber: epNum,
      })

      if (existingEp && existingEp.status === "uploaded") {
        skippedEpisodes.push(epNum)
        continue // Skip already processed
      }

      // Create or update episode record
      const episodeId = existingEp?._id?.toString() || new ObjectId().toString()

      const episode: Episode = {
        _id: episodeId,
        seriesId: series._id?.toString() || "",
        episodeNumber: epNum,
        title: `Episode ${epNum}`,
        status: "pending",
        languages: [],
        retries: 0,
        createdAt: existingEp?.createdAt || new Date(),
        updatedAt: new Date(),
      }

      if (!existingEp) {
        await episodesCollection.insertOne(episode as any)
      } else {
        await episodesCollection.updateOne(
          { _id: existingEp._id },
          { $set: { status: "pending", updatedAt: new Date() } },
        )
      }

      // Add to download queue
      await downloadQueue.addJob({
        episodeId,
        seriesId: series._id?.toString() || "",
        source,
        episodeNumber: epNum,
        sourceEpisodeId: `${animeId}-episode-${epNum}`,
        episodeUrl: animeUrl ? `${animeUrl}/episode-${epNum}` : undefined,
      })

      queuedEpisodes.push(episodeId)
    }

    console.log(`[Extract] Queued: ${queuedEpisodes.length}, Skipped: ${skippedEpisodes.length}`)

    return NextResponse.json({
      success: true,
      seriesId: series._id?.toString(),
      seriesTitle: series.title,
      queuedEpisodes,
      skippedEpisodes,
      queueStatus: downloadQueue.getStatus(),
    })
  } catch (error) {
    console.error("[Extract] Error:", error)
    return NextResponse.json(
      {
        error: "Extraction failed",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
