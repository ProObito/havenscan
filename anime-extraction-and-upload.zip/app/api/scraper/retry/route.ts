// API Route: Retry failed episodes

import { type NextRequest, NextResponse } from "next/server"
import { downloadQueue } from "@/lib/download-queue"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { episodeId, retryAll, maxRetries = 3 } = body

    if (retryAll) {
      // Retry all failed episodes
      const count = await downloadQueue.retryFailed(maxRetries)
      return NextResponse.json({
        success: true,
        message: `Re-queued ${count} failed episodes`,
        count,
      })
    }

    if (episodeId) {
      // Retry specific episode
      const success = await downloadQueue.retryEpisode(episodeId)
      return NextResponse.json({
        success,
        message: success ? "Episode re-queued" : "Episode not found",
      })
    }

    return NextResponse.json({ error: "Missing episodeId or retryAll flag" }, { status: 400 })
  } catch (error) {
    console.error("Retry error:", error)
    return NextResponse.json({ error: "Retry failed" }, { status: 500 })
  }
}
