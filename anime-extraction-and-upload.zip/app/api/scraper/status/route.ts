// API Route: Get scraper and queue status

import { NextResponse } from "next/server"
import { getJobsCollection, getEpisodesCollection } from "@/lib/db"
import { downloadQueue } from "@/lib/download-queue"

export async function GET() {
  try {
    await downloadQueue.initialize()

    const jobs = await getJobsCollection()
    const episodes = await getEpisodesCollection()

    // Get job stats
    const [pendingJobs, runningJobs, completedJobs, failedJobs] = await Promise.all([
      jobs.countDocuments({ status: "pending" }),
      jobs.countDocuments({ status: "running" }),
      jobs.countDocuments({ status: "completed" }),
      jobs.countDocuments({ status: "failed" }),
    ])

    // Get episode stats
    const [pendingEps, downloadingEps, uploadedEps, failedEps] = await Promise.all([
      episodes.countDocuments({ status: "pending" }),
      episodes.countDocuments({ status: { $in: ["extracting", "downloading", "uploading"] } }),
      episodes.countDocuments({ status: "uploaded" }),
      episodes.countDocuments({ status: "failed" }),
    ])

    // Get recent jobs with more details
    const recentJobs = await jobs.find({}).sort({ updatedAt: -1 }).limit(20).toArray()

    const queuedJobs = downloadQueue.getQueuedJobs()

    return NextResponse.json({
      queue: downloadQueue.getStatus(),
      queuedJobs: queuedJobs.map((j) => ({
        episodeId: j.episodeId,
        seriesId: j.seriesId,
        episodeNumber: j.episodeNumber,
        source: j.source,
      })),
      jobs: {
        pending: pendingJobs,
        running: runningJobs,
        completed: completedJobs,
        failed: failedJobs,
      },
      episodes: {
        pending: pendingEps,
        processing: downloadingEps,
        uploaded: uploadedEps,
        failed: failedEps,
      },
      recentJobs,
    })
  } catch (error) {
    console.error("Status error:", error)
    return NextResponse.json({ error: "Failed to get status" }, { status: 500 })
  }
}
