// API Route: Search anime across sources

import { type NextRequest, NextResponse } from "next/server"
import { sourceAdapter, type SourceType } from "@/lib/source-adapters"

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const query = searchParams.get("q")
  const source = searchParams.get("source") as SourceType | "all" | null

  if (!query) {
    return NextResponse.json({ error: "Query parameter required" }, { status: 400 })
  }

  try {
    let results

    if (!source || source === "all") {
      results = await sourceAdapter.searchAll(query)
    } else {
      results = await sourceAdapter.search(source, query)
    }

    return NextResponse.json({ results })
  } catch (error) {
    console.error("Search error:", error)
    return NextResponse.json({ error: "Search failed" }, { status: 500 })
  }
}
