// API Route: Episode operations

import { type NextRequest, NextResponse } from "next/server"
import { getEpisodesCollection } from "@/lib/db"
import { ObjectId } from "mongodb"

// GET - Get episode details
export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params

  try {
    const episodes = await getEpisodesCollection()
    const episode = await episodes.findOne({ _id: new ObjectId(id) as any })

    if (!episode) {
      return NextResponse.json({ error: "Episode not found" }, { status: 404 })
    }

    return NextResponse.json({ episode })
  } catch (error) {
    console.error("Episode fetch error:", error)
    return NextResponse.json({ error: "Failed to fetch episode" }, { status: 500 })
  }
}

// PATCH - Update episode (for manual edits)
export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params

  try {
    const body = await request.json()
    const episodes = await getEpisodesCollection()

    const result = await episodes.updateOne(
      { _id: new ObjectId(id) as any },
      {
        $set: {
          ...body,
          updatedAt: new Date(),
        },
      },
    )

    if (result.matchedCount === 0) {
      return NextResponse.json({ error: "Episode not found" }, { status: 404 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Episode update error:", error)
    return NextResponse.json({ error: "Failed to update episode" }, { status: 500 })
  }
}
