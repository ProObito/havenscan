// API Route: Get site statistics

import { NextResponse } from "next/server"
import { getSeriesCollection, getEpisodesCollection, getUsersCollection } from "@/lib/db"
import type { SiteStats } from "@/lib/types"

export async function GET() {
  try {
    const series = await getSeriesCollection()
    const episodes = await getEpisodesCollection()
    const users = await getUsersCollection()

    const [totalAnime, totalDonghua, totalEpisodes, totalUsers, premiumUsers] = await Promise.all([
      series.countDocuments({ type: "anime" }),
      series.countDocuments({ type: "donghua" }),
      episodes.countDocuments({ status: "uploaded" }),
      users.countDocuments({}),
      users.countDocuments({ role: "premium" }),
    ])

    // Active users in last 24h (would need activity tracking)
    const activeUsers = await users.countDocuments({
      updatedAt: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) },
    })

    const stats: SiteStats = {
      totalUsers,
      premiumUsers,
      guestUsers: 0, // Would need session tracking
      activeUsers,
      totalAnime,
      totalDonghua,
      totalEpisodes,
      liveViewers: 0, // Would need real-time tracking
    }

    return NextResponse.json(stats)
  } catch (error) {
    console.error("Stats error:", error)
    return NextResponse.json({ error: "Failed to fetch stats" }, { status: 500 })
  }
}
