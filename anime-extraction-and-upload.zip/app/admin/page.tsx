"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/auth-context"
import { useRouter } from "next/navigation"
import { Header } from "@/components/header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Users,
  Film,
  Play,
  Eye,
  TrendingUp,
  Activity,
  Plus,
  RefreshCw,
  CheckCircle,
  XCircle,
  Clock,
  AlertCircle,
  LayoutDashboard,
  FileVideo,
  Settings2,
  List,
} from "lucide-react"
import { cn } from "@/lib/utils"
import type { SiteStats, ScraperJob } from "@/lib/types"

// Demo stats
const demoStats: SiteStats = {
  totalUsers: 12453,
  premiumUsers: 847,
  guestUsers: 5621,
  activeUsers: 234,
  totalAnime: 1847,
  totalDonghua: 423,
  totalEpisodes: 45623,
  liveViewers: 89,
}

// Demo scraper jobs
const demoJobs: ScraperJob[] = [
  {
    _id: "1",
    type: "episodes",
    source: "hianime",
    status: "completed",
    progress: 100,
    message: "Solo Leveling - 12 episodes",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: "2",
    type: "download",
    source: "hianime",
    status: "running",
    progress: 65,
    message: "Downloading episode 8...",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: "3",
    type: "upload",
    source: "desidub",
    status: "pending",
    progress: 0,
    message: "Queued for upload",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: "4",
    type: "search",
    source: "tpxsub",
    status: "failed",
    progress: 0,
    message: "Connection timeout",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
]

function AnimatedCounter({
  value,
  label,
  icon: Icon,
  color,
}: { value: number; label: string; icon: React.ElementType; color: string }) {
  const [count, setCount] = useState(0)

  useEffect(() => {
    const duration = 1000
    const steps = 30
    const increment = value / steps
    let current = 0

    const timer = setInterval(() => {
      current += increment
      if (current >= value) {
        setCount(value)
        clearInterval(timer)
      } else {
        setCount(Math.floor(current))
      }
    }, duration / steps)

    return () => clearInterval(timer)
  }, [value])

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{label}</p>
            <p className={cn("text-3xl font-bold", color)}>{count.toLocaleString()}</p>
          </div>
          <div className={cn("p-3 rounded-full bg-opacity-10", color.replace("text-", "bg-"))}>
            <Icon className={cn("h-6 w-6", color)} />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function StatusBadge({ status }: { status: string }) {
  const config = {
    completed: { color: "bg-green-500/10 text-green-500", icon: CheckCircle },
    running: { color: "bg-blue-500/10 text-blue-500", icon: RefreshCw },
    pending: { color: "bg-yellow-500/10 text-yellow-500", icon: Clock },
    failed: { color: "bg-red-500/10 text-red-500", icon: XCircle },
  }[status] || { color: "bg-gray-500/10 text-gray-500", icon: AlertCircle }

  return (
    <Badge variant="outline" className={cn("gap-1", config.color)}>
      <config.icon className={cn("h-3 w-3", status === "running" && "animate-spin")} />
      {status}
    </Badge>
  )
}

export default function AdminPage() {
  const { user, isAdmin } = useAuth()
  const router = useRouter()
  const [stats] = useState<SiteStats>(demoStats)
  const [jobs] = useState<ScraperJob[]>(demoJobs)
  const [scraperStatus, setScraperStatus] = useState<"idle" | "running">("idle")
  const [addEpisodeOpen, setAddEpisodeOpen] = useState(false)

  // Form state for adding episode
  const [episodeForm, setEpisodeForm] = useState({
    contentType: "anime",
    title: "",
    episodeNumber: "",
    language: "hindi",
    streamUrl: "",
    downloadUrl: "",
  })

  // Redirect non-admins
  useEffect(() => {
    if (!isAdmin) {
      router.push("/")
    }
  }, [isAdmin, router])

  if (!isAdmin) {
    return null
  }

  const handleTriggerScrape = async () => {
    setScraperStatus("running")
    // In production, call the API
    setTimeout(() => setScraperStatus("idle"), 3000)
  }

  const handleAddEpisode = async () => {
    // In production, call the API
    console.log("Adding episode:", episodeForm)
    setAddEpisodeOpen(false)
    setEpisodeForm({
      contentType: "anime",
      title: "",
      episodeNumber: "",
      language: "hindi",
      streamUrl: "",
      downloadUrl: "",
    })
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">Admin Dashboard</h1>
            <p className="text-muted-foreground">Manage content and monitor system status</p>
          </div>
          <Badge variant="outline" className="text-primary border-primary">
            {user?.role === "owner" ? "Owner" : "Admin"}
          </Badge>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview" className="gap-2">
              <LayoutDashboard className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="content" className="gap-2">
              <FileVideo className="h-4 w-4" />
              Content
            </TabsTrigger>
            <TabsTrigger value="scraper" className="gap-2">
              <Settings2 className="h-4 w-4" />
              Scraper
            </TabsTrigger>
            <TabsTrigger value="logs" className="gap-2">
              <List className="h-4 w-4" />
              Logs
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <AnimatedCounter value={stats.totalUsers} label="Total Users" icon={Users} color="text-blue-500" />
              <AnimatedCounter value={stats.activeUsers} label="Active Now" icon={Activity} color="text-green-500" />
              <AnimatedCounter value={stats.liveViewers} label="Live Viewers" icon={Eye} color="text-purple-500" />
              <AnimatedCounter
                value={stats.premiumUsers}
                label="Premium Users"
                icon={TrendingUp}
                color="text-yellow-500"
              />
            </div>

            {/* Content Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Film className="h-5 w-5 text-primary" />
                    Anime
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold">{stats.totalAnime.toLocaleString()}</p>
                  <p className="text-sm text-muted-foreground">Total series</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Film className="h-5 w-5 text-accent" />
                    Donghua
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold">{stats.totalDonghua.toLocaleString()}</p>
                  <p className="text-sm text-muted-foreground">Total series</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Play className="h-5 w-5 text-green-500" />
                    Episodes
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold">{stats.totalEpisodes.toLocaleString()}</p>
                  <p className="text-sm text-muted-foreground">Total episodes</p>
                </CardContent>
              </Card>
            </div>

            {/* User Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>User Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <div className="flex-1">
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Logged-in Users</span>
                        <span className="text-sm font-medium">{stats.totalUsers - stats.guestUsers}</span>
                      </div>
                      <div className="h-2 bg-secondary rounded-full overflow-hidden">
                        <div
                          className="h-full bg-blue-500 rounded-full transition-all duration-500"
                          style={{ width: `${((stats.totalUsers - stats.guestUsers) / stats.totalUsers) * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex-1">
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Guest Users</span>
                        <span className="text-sm font-medium">{stats.guestUsers}</span>
                      </div>
                      <div className="h-2 bg-secondary rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gray-500 rounded-full transition-all duration-500"
                          style={{ width: `${(stats.guestUsers / stats.totalUsers) * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex-1">
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Premium Users</span>
                        <span className="text-sm font-medium">{stats.premiumUsers}</span>
                      </div>
                      <div className="h-2 bg-secondary rounded-full overflow-hidden">
                        <div
                          className="h-full bg-yellow-500 rounded-full transition-all duration-500"
                          style={{ width: `${(stats.premiumUsers / stats.totalUsers) * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Content Management Tab */}
          <TabsContent value="content" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Content Management</CardTitle>
                    <CardDescription>Add and manage episodes manually</CardDescription>
                  </div>
                  <Dialog open={addEpisodeOpen} onOpenChange={setAddEpisodeOpen}>
                    <DialogTrigger asChild>
                      <Button className="gap-2">
                        <Plus className="h-4 w-4" />
                        Add Episode
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Add New Episode</DialogTitle>
                        <DialogDescription>Manually add an episode with stream and download links</DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4 py-4">
                        <div className="space-y-2">
                          <Label>Content Type</Label>
                          <Select
                            value={episodeForm.contentType}
                            onValueChange={(v) => setEpisodeForm({ ...episodeForm, contentType: v })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="anime">Anime</SelectItem>
                              <SelectItem value="donghua">Donghua</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label>Title / Series Name</Label>
                          <Input
                            placeholder="e.g., Solo Leveling"
                            value={episodeForm.title}
                            onChange={(e) => setEpisodeForm({ ...episodeForm, title: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Episode Number</Label>
                          <Input
                            type="number"
                            placeholder="e.g., 12"
                            value={episodeForm.episodeNumber}
                            onChange={(e) => setEpisodeForm({ ...episodeForm, episodeNumber: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Language</Label>
                          <Select
                            value={episodeForm.language}
                            onValueChange={(v) => setEpisodeForm({ ...episodeForm, language: v })}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="hindi">Hindi</SelectItem>
                              <SelectItem value="tamil">Tamil</SelectItem>
                              <SelectItem value="telugu">Telugu</SelectItem>
                              <SelectItem value="english-sub">English Sub</SelectItem>
                              <SelectItem value="english-dub">English Dub</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label>Stream Embed URL</Label>
                          <Input
                            placeholder="Steamtape / DoodStream embed URL"
                            value={episodeForm.streamUrl}
                            onChange={(e) => setEpisodeForm({ ...episodeForm, streamUrl: e.target.value })}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Download URL (Optional)</Label>
                          <Input
                            placeholder="Direct download link"
                            value={episodeForm.downloadUrl}
                            onChange={(e) => setEpisodeForm({ ...episodeForm, downloadUrl: e.target.value })}
                          />
                        </div>
                        <Button onClick={handleAddEpisode} className="w-full">
                          Add Episode
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-center py-8">
                  Use the &quot;Add Episode&quot; button to manually add content with stream/download links.
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Scraper Tab */}
          <TabsContent value="scraper" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Scraper Control</CardTitle>
                    <CardDescription>Manage automated content extraction</CardDescription>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant={scraperStatus === "running" ? "default" : "secondary"}>
                      {scraperStatus === "running" ? "Running" : "Idle"}
                    </Badge>
                    <Button onClick={handleTriggerScrape} disabled={scraperStatus === "running"} className="gap-2">
                      <RefreshCw className={cn("h-4 w-4", scraperStatus === "running" && "animate-spin")} />
                      {scraperStatus === "running" ? "Scraping..." : "Trigger Scrape"}
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4">
                  <Card className="bg-secondary/30">
                    <CardContent className="p-4">
                      <p className="font-medium">HiAnime</p>
                      <p className="text-xs text-muted-foreground">API-based extraction</p>
                      <Badge variant="outline" className="mt-2 text-green-500">
                        Active
                      </Badge>
                    </CardContent>
                  </Card>
                  <Card className="bg-secondary/30">
                    <CardContent className="p-4">
                      <p className="font-medium">TPXSub</p>
                      <p className="text-xs text-muted-foreground">Shortener resolution</p>
                      <Badge variant="outline" className="mt-2 text-yellow-500">
                        Limited
                      </Badge>
                    </CardContent>
                  </Card>
                  <Card className="bg-secondary/30">
                    <CardContent className="p-4">
                      <p className="font-medium">DesiDubAnime</p>
                      <p className="text-xs text-muted-foreground">iFrame extraction</p>
                      <Badge variant="outline" className="mt-2 text-green-500">
                        Active
                      </Badge>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Last Update</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Last successful scrape: <span className="text-foreground font-medium">2 hours ago</span>
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Logs Tab */}
          <TabsContent value="logs" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Last 5 scraper jobs</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px]">
                  <div className="space-y-3">
                    {jobs.map((job) => (
                      <div
                        key={job._id}
                        className="flex items-center justify-between p-3 rounded-lg bg-secondary/30 border border-border/50"
                      >
                        <div className="flex items-center gap-3">
                          <StatusBadge status={job.status} />
                          <div>
                            <p className="font-medium">{job.message}</p>
                            <p className="text-xs text-muted-foreground">
                              {job.type} • {job.source}
                            </p>
                          </div>
                        </div>
                        {job.status === "running" && (
                          <div className="text-sm text-muted-foreground">{job.progress}%</div>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
