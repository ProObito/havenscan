"use client"

import { useState } from "react"
import Link from "next/link"
import { Header } from "@/components/header"
import { AnimeCard } from "@/components/anime-card"
import { ThemeAnimations } from "@/components/theme-animations"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Play, Search, TrendingUp, Clock, Star, ChevronRight } from "lucide-react"
import type { Series } from "@/lib/types"

// Demo data - replace with API calls
const demoAnime: Series[] = [
  {
    _id: "1",
    title: "Solo Leveling",
    slug: "solo-leveling",
    poster: "/solo-leveling-anime-poster.jpg",
    description: "In a world where hunters must battle deadly monsters to protect humanity...",
    source: "hianime",
    sourceUrl: "",
    sourceId: "solo-leveling",
    type: "anime",
    status: "ongoing",
    language: ["Japanese", "Hindi", "English"],
    genres: ["Action", "Fantasy", "Adventure"],
    year: 2024,
    rating: 8.9,
    totalEpisodes: 12,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: "2",
    title: "Demon Slayer",
    slug: "demon-slayer",
    poster: "/demon-slayer-anime-poster.png",
    description: "Tanjiro Kamado sets out to become a demon slayer after his family is slaughtered...",
    source: "hianime",
    sourceUrl: "",
    sourceId: "demon-slayer",
    type: "anime",
    status: "completed",
    language: ["Japanese", "Hindi"],
    genres: ["Action", "Supernatural"],
    year: 2019,
    rating: 8.7,
    totalEpisodes: 26,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: "3",
    title: "Jujutsu Kaisen",
    slug: "jujutsu-kaisen",
    poster: "/jujutsu-kaisen-poster.png",
    description: "A boy swallows a cursed talisman and becomes host to a powerful curse...",
    source: "hianime",
    sourceUrl: "",
    sourceId: "jujutsu-kaisen",
    type: "anime",
    status: "ongoing",
    language: ["Japanese", "English"],
    genres: ["Action", "Supernatural", "School"],
    year: 2020,
    rating: 8.6,
    totalEpisodes: 48,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: "4",
    title: "Attack on Titan",
    slug: "attack-on-titan",
    poster: "/anime-poster.png",
    description: "Humanity lives inside cities surrounded by enormous walls due to the Titans...",
    source: "hianime",
    sourceUrl: "",
    sourceId: "attack-on-titan",
    type: "anime",
    status: "completed",
    language: ["Japanese", "Hindi", "English", "Tamil"],
    genres: ["Action", "Drama", "Military"],
    year: 2013,
    rating: 9.0,
    totalEpisodes: 87,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: "5",
    title: "Soul Land",
    slug: "soul-land",
    poster: "/soul-land-donghua-poster.jpg",
    description: "Tang San spent his life in the Tang Outer Sect, dedicated to the creation...",
    source: "desidub",
    sourceUrl: "",
    sourceId: "soul-land",
    type: "donghua",
    status: "ongoing",
    language: ["Chinese", "Hindi"],
    genres: ["Action", "Fantasy", "Romance"],
    year: 2018,
    rating: 8.3,
    totalEpisodes: 260,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: "6",
    title: "Battle Through the Heavens",
    slug: "battle-through-the-heavens",
    poster: "/battle-through-heavens-donghua-poster.jpg",
    description: "In a land where there is no magic, a land where the strong make the rules...",
    source: "desidub",
    sourceUrl: "",
    sourceId: "btth",
    type: "donghua",
    status: "ongoing",
    language: ["Chinese", "Hindi", "English"],
    genres: ["Action", "Fantasy", "Martial Arts"],
    year: 2017,
    rating: 8.1,
    totalEpisodes: 52,
    createdAt: new Date(),
    updatedAt: new Date(),
  },
]

export default function HomePage() {
  const [featuredAnime] = useState(demoAnime[0])
  const [trendingAnime] = useState(demoAnime.slice(0, 6))
  const [latestAnime] = useState(demoAnime.slice(0, 6))
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ThemeAnimations />
      <Header />

      {/* Hero Section */}
      <section className="relative h-[70vh] min-h-[500px] overflow-hidden">
        {/* Background Image */}
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url(${featuredAnime.banner || featuredAnime.poster})`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />

        {/* Content */}
        <div className="container mx-auto px-4 h-full flex items-center relative z-10">
          <div className="max-w-2xl space-y-6">
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="bg-primary text-primary-foreground">
                Featured
              </Badge>
              <Badge variant="outline">{featuredAnime.type === "donghua" ? "Donghua" : "Anime"}</Badge>
              {featuredAnime.rating && (
                <Badge variant="secondary" className="bg-yellow-500/90 text-black flex items-center gap-1">
                  <Star className="h-3 w-3 fill-current" />
                  {featuredAnime.rating}
                </Badge>
              )}
            </div>

            <h1 className="text-4xl md:text-6xl font-bold text-balance">{featuredAnime.title}</h1>

            <p className="text-lg text-foreground/80 line-clamp-3">{featuredAnime.description}</p>

            <div className="flex flex-wrap items-center gap-2">
              {featuredAnime.genres.slice(0, 4).map((genre) => (
                <Badge key={genre} variant="outline">
                  {genre}
                </Badge>
              ))}
              <span className="text-sm text-muted-foreground">
                • {featuredAnime.year} • {featuredAnime.totalEpisodes} Episodes
              </span>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <Button size="lg" className="gap-2" asChild>
                <Link href={`/watch/${featuredAnime.slug}`}>
                  <Play className="h-5 w-5 fill-current" />
                  Watch Now
                </Link>
              </Button>
              <Button size="lg" variant="outline">
                + Add to List
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Search */}
      <section className="container mx-auto px-4 -mt-8 relative z-20">
        <div className="bg-card/80 backdrop-blur-xl rounded-2xl p-4 border border-border/50 shadow-xl">
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="Search for anime, donghua, genres..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-12 bg-background/50"
              />
            </div>
            <Button size="lg" asChild>
              <Link href={`/search?q=${encodeURIComponent(searchQuery)}`}>Search</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Trending Section */}
      <section className="container mx-auto px-4 py-12">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-6 w-6 text-primary" />
            <h2 className="text-2xl font-bold">Trending Now</h2>
          </div>
          <Button variant="ghost" className="gap-1" asChild>
            <Link href="/trending">
              View All
              <ChevronRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {trendingAnime.map((anime) => (
            <AnimeCard key={anime._id} anime={anime} />
          ))}
        </div>
      </section>

      {/* Latest Episodes Section */}
      <section className="container mx-auto px-4 py-12">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Clock className="h-6 w-6 text-primary" />
            <h2 className="text-2xl font-bold">Latest Episodes</h2>
          </div>
          <Button variant="ghost" className="gap-1" asChild>
            <Link href="/latest">
              View All
              <ChevronRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {latestAnime.map((anime) => (
            <AnimeCard key={anime._id} anime={anime} />
          ))}
        </div>
      </section>

      {/* Anime Section */}
      <section className="container mx-auto px-4 py-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Popular Anime</h2>
          <Button variant="ghost" className="gap-1" asChild>
            <Link href="/anime">
              View All
              <ChevronRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {demoAnime
            .filter((a) => a.type === "anime")
            .map((anime) => (
              <AnimeCard key={anime._id} anime={anime} />
            ))}
        </div>
      </section>

      {/* Donghua Section */}
      <section className="container mx-auto px-4 py-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Popular Donghua</h2>
          <Button variant="ghost" className="gap-1" asChild>
            <Link href="/donghua">
              View All
              <ChevronRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {demoAnime
            .filter((a) => a.type === "donghua")
            .map((anime) => (
              <AnimeCard key={anime._id} anime={anime} />
            ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/40 bg-card/50 backdrop-blur-xl">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold text-primary mb-4">AniCrew</h3>
              <p className="text-sm text-muted-foreground">
                Your ultimate destination for anime and donghua streaming.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Browse</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="/anime" className="hover:text-foreground transition-colors">
                    Anime
                  </Link>
                </li>
                <li>
                  <Link href="/donghua" className="hover:text-foreground transition-colors">
                    Donghua
                  </Link>
                </li>
                <li>
                  <Link href="/trending" className="hover:text-foreground transition-colors">
                    Trending
                  </Link>
                </li>
                <li>
                  <Link href="/latest" className="hover:text-foreground transition-colors">
                    Latest
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Account</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="/login" className="hover:text-foreground transition-colors">
                    Login
                  </Link>
                </li>
                <li>
                  <Link href="/register" className="hover:text-foreground transition-colors">
                    Register
                  </Link>
                </li>
                <li>
                  <Link href="/watchlist" className="hover:text-foreground transition-colors">
                    Watchlist
                  </Link>
                </li>
                <li>
                  <Link href="/premium" className="hover:text-foreground transition-colors">
                    Premium
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>
                  <Link href="/terms" className="hover:text-foreground transition-colors">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="hover:text-foreground transition-colors">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/dmca" className="hover:text-foreground transition-colors">
                    DMCA
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border/40 mt-8 pt-8 text-center text-sm text-muted-foreground">
            <p>© 2026 AniCrew. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
