"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { ThemeAnimations } from "@/components/theme-animations"
import { useTheme } from "@/contexts/theme-context"
import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { darkThemes, lightThemes, specialThemes, type allThemes } from "@/lib/themes"
import { cn } from "@/lib/utils"
import { Check, Moon, Sun, Sparkles, User, Palette, Bell, Shield, Save } from "lucide-react"

export default function SettingsPage() {
  const { theme, setTheme } = useTheme()
  const { user, updateProfile } = useAuth()
  const [displayName, setDisplayName] = useState(user?.displayName || "")
  const [username, setUsername] = useState(user?.username || "")
  const [notifications, setNotifications] = useState({
    newEpisodes: true,
    recommendations: false,
    comments: true,
  })

  const handleProfileUpdate = async () => {
    await updateProfile({ displayName, username })
  }

  const ThemeGrid = ({ themes }: { themes: typeof allThemes }) => (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
      {themes.map((t) => (
        <button
          key={t.id}
          onClick={() => setTheme(t.id)}
          className={cn(
            "relative p-3 rounded-xl border-2 transition-all text-left",
            theme.id === t.id ? "border-primary bg-primary/10" : "border-border hover:border-primary/50",
          )}
        >
          <div className="flex gap-1.5 mb-2">
            <div className="h-6 w-6 rounded-full border" style={{ backgroundColor: t.colors.background }} />
            <div className="h-6 w-6 rounded-full border" style={{ backgroundColor: t.colors.primary }} />
            <div className="h-6 w-6 rounded-full border" style={{ backgroundColor: t.colors.accent }} />
          </div>
          <p className="text-sm font-medium">{t.name}</p>
          <p className="text-xs text-muted-foreground capitalize">{t.mode}</p>

          {theme.id === t.id && (
            <div className="absolute top-2 right-2">
              <Check className="h-4 w-4 text-primary" />
            </div>
          )}

          {t.animation && (
            <div className="absolute bottom-2 right-2">
              <Sparkles className="h-3 w-3 text-yellow-500" />
            </div>
          )}
        </button>
      ))}
    </div>
  )

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ThemeAnimations />
      <Header />

      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Settings</h1>

        <Tabs defaultValue="themes" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:inline-grid">
            <TabsTrigger value="themes" className="gap-2">
              <Palette className="h-4 w-4" />
              <span className="hidden sm:inline">Themes</span>
            </TabsTrigger>
            <TabsTrigger value="profile" className="gap-2">
              <User className="h-4 w-4" />
              <span className="hidden sm:inline">Profile</span>
            </TabsTrigger>
            <TabsTrigger value="notifications" className="gap-2">
              <Bell className="h-4 w-4" />
              <span className="hidden sm:inline">Notifications</span>
            </TabsTrigger>
            <TabsTrigger value="privacy" className="gap-2">
              <Shield className="h-4 w-4" />
              <span className="hidden sm:inline">Privacy</span>
            </TabsTrigger>
          </TabsList>

          {/* Themes Tab */}
          <TabsContent value="themes" className="space-y-6" id="themes">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Moon className="h-5 w-5" />
                  Dark Themes
                </CardTitle>
                <CardDescription>Elegant dark themes for comfortable viewing</CardDescription>
              </CardHeader>
              <CardContent>
                <ThemeGrid themes={darkThemes} />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sun className="h-5 w-5" />
                  Light Themes
                </CardTitle>
                <CardDescription>Bright and clean light themes</CardDescription>
              </CardHeader>
              <CardContent>
                <ThemeGrid themes={lightThemes} />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5" />
                  Special Animated Themes
                </CardTitle>
                <CardDescription>Themes with beautiful background animations</CardDescription>
              </CardHeader>
              <CardContent>
                <ThemeGrid themes={specialThemes} />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Profile Information</CardTitle>
                <CardDescription>Update your profile details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="displayName">Display Name</Label>
                  <Input
                    id="displayName"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="Your display name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <Input
                    id="username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="your_username"
                  />
                </div>
                <Button onClick={handleProfileUpdate} className="gap-2">
                  <Save className="h-4 w-4" />
                  Save Changes
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notifications Tab */}
          <TabsContent value="notifications" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Notification Preferences</CardTitle>
                <CardDescription>Manage your notification settings</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">New Episodes</p>
                    <p className="text-sm text-muted-foreground">Get notified when new episodes are released</p>
                  </div>
                  <Switch
                    checked={notifications.newEpisodes}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, newEpisodes: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Recommendations</p>
                    <p className="text-sm text-muted-foreground">Receive personalized anime recommendations</p>
                  </div>
                  <Switch
                    checked={notifications.recommendations}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, recommendations: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Comments & Replies</p>
                    <p className="text-sm text-muted-foreground">Get notified about replies to your comments</p>
                  </div>
                  <Switch
                    checked={notifications.comments}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, comments: checked })}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Privacy Tab */}
          <TabsContent value="privacy" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Privacy Settings</CardTitle>
                <CardDescription>Control your privacy preferences</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Public Watchlist</p>
                    <p className="text-sm text-muted-foreground">Allow others to see your watchlist</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Show Watch History</p>
                    <p className="text-sm text-muted-foreground">Display your recently watched anime</p>
                  </div>
                  <Switch defaultChecked={false} />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
