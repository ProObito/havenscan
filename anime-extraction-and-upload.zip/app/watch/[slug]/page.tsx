"use client"

import { useState, use } from "react"
import Link from "next/link"
import Image from "next/image"
import { Header } from "@/components/header"
import { VideoPlayer } from "@/components/video-player"
import { CommentSection } from "@/components/comment-section"
import { ThemeAnimations } from "@/components/theme-animations"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Play, Plus, Check, Download, Lock, Star, Calendar, Clock, Film, Share2 } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Series, Episode, Comment } from "@/lib/types"

// Demo data
const demoSeries: Series = {
  _id: "1",
  title: "Solo Leveling",
  slug: "solo-leveling",
  poster: "/solo-leveling-anime-poster.jpg",
  banner: "/solo-leveling-anime-banner.jpg",
  description:
    "In a world where hunters must battle deadly monsters to protect humanity, Sung Jinwoo, a notoriously weak hunter, finds himself in a perilous dungeon. After narrowly surviving, he discovers a mysterious program called the System that gives him the unique ability to level up in strength. As he grows stronger, he uncovers secrets about the dungeons and his own past that threaten the balance between worlds.",
  source: "hianime",
  sourceUrl: "",
  sourceId: "solo-leveling",
  type: "anime",
  status: "ongoing",
  language: ["Japanese", "Hindi", "English", "Tamil", "Telugu"],
  genres: ["Action", "Fantasy", "Adventure", "Supernatural"],
  year: 2024,
  rating: 8.9,
  totalEpisodes: 12,
  createdAt: new Date(),
  updatedAt: new Date(),
}

const demoEpisodes: Episode[] = Array.from({ length: 12 }, (_, i) => ({
  _id: `ep-${i + 1}`,
  seriesId: "1",
  episodeNumber: i + 1,
  title: `Episode ${i + 1}`,
  thumbnail: `/placeholder.svg?height=150&width=250&query=solo leveling episode ${i + 1}`,
  duration: 24,
  status: "uploaded",
  streamUrl: "https://example.com/stream.m3u8",
  downloadUrl: `https://dood.so/e/sample${i + 1}`,
  remoteId: `dood${i + 1}`,
  languages: [
    { audio: "Japanese", subtitle: "English", streamUrl: "https://example.com/jp.m3u8" },
    { audio: "Hindi", streamUrl: "https://example.com/hi.m3u8" },
    { audio: "English", streamUrl: "https://example.com/en.m3u8" },
  ],
  retries: 0,
  createdAt: new Date(),
  updatedAt: new Date(),
}))

const demoComments: Comment[] = [
  {
    _id: "c1",
    userId: "u1",
    seriesId: "1",
    content: "This anime is absolutely incredible! The animation quality is top-notch.",
    likes: ["u2", "u3"],
    replies: [{ userId: "u2", content: "Totally agree! Best anime of 2024.", createdAt: new Date() }],
    createdAt: new Date(Date.now() - 86400000),
    updatedAt: new Date(),
  },
  {
    _id: "c2",
    userId: "u2",
    seriesId: "1",
    content: "The Hindi dub is really well done. Great voice actors!",
    likes: ["u1"],
    replies: [],
    createdAt: new Date(Date.now() - 172800000),
    updatedAt: new Date(),
  },
]

export default function WatchPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params)
  const { user, isPremium } = useAuth()
  const [series] = useState<Series>(demoSeries)
  const [episodes] = useState<Episode[]>(demoEpisodes)
  const [comments, setComments] = useState<Comment[]>(demoComments)
  const [currentEpisode, setCurrentEpisode] = useState<Episode>(demoEpisodes[0])
  const [selectedLanguage, setSelectedLanguage] = useState("Japanese")
  const [isInWatchlist, setIsInWatchlist] = useState(false)

  const currentEpisodeIndex = episodes.findIndex((ep) => ep._id === currentEpisode._id)
  const hasPrevious = currentEpisodeIndex > 0
  const hasNext = currentEpisodeIndex < episodes.length - 1

  const handlePreviousEpisode = () => {
    if (hasPrevious) {
      setCurrentEpisode(episodes[currentEpisodeIndex - 1])
    }
  }

  const handleNextEpisode = () => {
    if (hasNext) {
      setCurrentEpisode(episodes[currentEpisodeIndex + 1])
    }
  }

  const handleAddComment = async (content: string) => {
    const newComment: Comment = {
      _id: `c${Date.now()}`,
      userId: user?._id || "",
      seriesId: series._id || "",
      content,
      likes: [],
      replies: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    setComments([newComment, ...comments])
  }

  const handleLikeComment = async (commentId: string) => {
    setComments(
      comments.map((c) => {
        if (c._id === commentId) {
          const userId = user?._id || ""
          const likes = c.likes.includes(userId) ? c.likes.filter((id) => id !== userId) : [...c.likes, userId]
          return { ...c, likes }
        }
        return c
      }),
    )
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <ThemeAnimations />
      <Header />

      {/* Video Player Section */}
      <section className="bg-black">
        <div className="container mx-auto px-4 py-4">
          <VideoPlayer
            embedUrl={currentEpisode.downloadUrl}
            title={`${series.title} - ${currentEpisode.title}`}
            languages={currentEpisode.languages.map((l) => ({ label: l.audio, url: l.streamUrl }))}
            subtitles={[
              { label: "Hindi Sub", url: "/subs/hi.vtt" },
              { label: "English Sub", url: "/subs/en.vtt" },
            ]}
            onPrevious={handlePreviousEpisode}
            onNext={handleNextEpisode}
            hasPrevious={hasPrevious}
            hasNext={hasNext}
          />
        </div>
      </section>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Episode Info */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl font-bold">{series.title}</h1>
                <p className="text-muted-foreground">{currentEpisode.title}</p>
              </div>

              <div className="flex items-center gap-2">
                {/* Language Selector */}
                <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                  <SelectTrigger className="w-[140px]">
                    <SelectValue placeholder="Language" />
                  </SelectTrigger>
                  <SelectContent>
                    {currentEpisode.languages.map((lang) => (
                      <SelectItem key={lang.audio} value={lang.audio}>
                        {lang.audio}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {/* Download Button */}
                {isPremium ? (
                  <Button variant="outline" className="gap-2 bg-transparent">
                    <Download className="h-4 w-4" />
                    Download
                  </Button>
                ) : (
                  <Button variant="outline" className="gap-2 bg-transparent" disabled>
                    <Lock className="h-4 w-4" />
                    Premium Only
                  </Button>
                )}

                {/* Share */}
                <Button variant="ghost" size="icon">
                  <Share2 className="h-5 w-5" />
                </Button>
              </div>
            </div>

            {/* Tabs */}
            <Tabs defaultValue="episodes">
              <TabsList>
                <TabsTrigger value="episodes">Episodes</TabsTrigger>
                <TabsTrigger value="details">Details</TabsTrigger>
                <TabsTrigger value="comments">Comments ({comments.length})</TabsTrigger>
              </TabsList>

              <TabsContent value="episodes" className="mt-4">
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                  {episodes.map((ep) => (
                    <button
                      key={ep._id}
                      onClick={() => setCurrentEpisode(ep)}
                      className={cn(
                        "relative aspect-video rounded-lg overflow-hidden group transition-all",
                        currentEpisode._id === ep._id ? "ring-2 ring-primary" : "hover:ring-1 hover:ring-border",
                      )}
                    >
                      <Image
                        src={ep.thumbnail || "/placeholder.svg?height=150&width=250&query=episode thumbnail"}
                        alt={ep.title}
                        fill
                        className="object-cover"
                      />
                      <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <Play className="h-8 w-8 text-white" />
                      </div>
                      <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black">
                        <p className="text-xs text-white font-medium">Ep {ep.episodeNumber}</p>
                      </div>
                      {currentEpisode._id === ep._id && (
                        <div className="absolute top-2 right-2">
                          <Badge className="bg-primary text-[10px]">Playing</Badge>
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="details" className="mt-4">
                <div className="space-y-4">
                  <p className="text-foreground/80 leading-relaxed">{series.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {series.genres.map((genre) => (
                      <Badge key={genre} variant="secondary">
                        {genre}
                      </Badge>
                    ))}
                  </div>
                  <div className="grid grid-cols-2 gap-4 pt-4">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      <span>{series.year}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Film className="h-4 w-4" />
                      <span>{series.totalEpisodes} Episodes</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Star className="h-4 w-4 text-yellow-500" />
                      <span>{series.rating} / 10</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="h-4 w-4" />
                      <span>{series.status}</span>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="comments" className="mt-4">
                <CommentSection
                  seriesId={series._id || ""}
                  episodeId={currentEpisode._id}
                  comments={comments}
                  onAddComment={handleAddComment}
                  onLikeComment={handleLikeComment}
                />
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Series Card */}
            <div className="bg-card rounded-xl border border-border/50 overflow-hidden">
              <div className="aspect-[2/3] relative">
                <Image src={series.poster || "/placeholder.svg"} alt={series.title} fill className="object-cover" />
              </div>
              <div className="p-4 space-y-4">
                <h3 className="font-semibold">{series.title}</h3>
                <div className="flex items-center gap-2">
                  {series.rating && (
                    <Badge className="bg-yellow-500/90 text-black gap-1">
                      <Star className="h-3 w-3 fill-current" />
                      {series.rating}
                    </Badge>
                  )}
                  <Badge variant="outline">{series.status}</Badge>
                </div>
                <Button
                  className="w-full gap-2"
                  variant={isInWatchlist ? "secondary" : "default"}
                  onClick={() => setIsInWatchlist(!isInWatchlist)}
                >
                  {isInWatchlist ? (
                    <>
                      <Check className="h-4 w-4" />
                      In Watchlist
                    </>
                  ) : (
                    <>
                      <Plus className="h-4 w-4" />
                      Add to Watchlist
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Available Languages */}
            <div className="bg-card rounded-xl border border-border/50 p-4">
              <h4 className="font-semibold mb-3">Available Languages</h4>
              <div className="flex flex-wrap gap-2">
                {series.language.map((lang) => (
                  <Badge key={lang} variant="secondary">
                    {lang}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Premium CTA */}
            {!isPremium && (
              <div className="bg-gradient-to-br from-primary/20 to-accent/20 rounded-xl border border-primary/30 p-4 space-y-3">
                <h4 className="font-semibold flex items-center gap-2">
                  <Lock className="h-4 w-4" />
                  Unlock Downloads
                </h4>
                <p className="text-sm text-muted-foreground">Get premium to download episodes and watch offline!</p>
                <Button className="w-full" asChild>
                  <Link href="/premium">Go Premium</Link>
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
