"use client"

import Link from "next/link"
import Image from "next/image"
import { useState } from "react"
import { Play, Plus, Check, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import type { Series } from "@/lib/types"

interface AnimeCardProps {
  anime: Series
  onAddToWatchlist?: () => void
  isInWatchlist?: boolean
}

export function AnimeCard({ anime, onAddToWatchlist, isInWatchlist }: AnimeCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const [imageError, setImageError] = useState(false)

  return (
    <div
      className="group relative rounded-xl overflow-hidden transition-all duration-300 hover:scale-[1.02] hover:shadow-xl hover:shadow-primary/10"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Card Background */}
      <div className="aspect-[2/3] relative bg-muted">
        {!imageError ? (
          <Image
            src={anime.poster || "/placeholder.svg?height=450&width=300&query=anime poster"}
            alt={anime.title}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-110"
            onError={() => setImageError(true)}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-secondary">
            <span className="text-4xl">🎬</span>
          </div>
        )}

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />

        {/* Top Badges */}
        <div className="absolute top-2 left-2 flex gap-1.5">
          {anime.type && (
            <Badge variant="secondary" className="text-xs bg-background/80 backdrop-blur-sm">
              {anime.type === "donghua" ? "Donghua" : "Anime"}
            </Badge>
          )}
          {anime.rating && (
            <Badge variant="secondary" className="text-xs bg-yellow-500/90 text-black flex items-center gap-0.5">
              <Star className="h-3 w-3 fill-current" />
              {anime.rating.toFixed(1)}
            </Badge>
          )}
        </div>

        {/* Hover Overlay */}
        <div
          className={cn(
            "absolute inset-0 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center gap-3 transition-opacity duration-300",
            isHovered ? "opacity-100" : "opacity-0",
          )}
        >
          <Link href={`/watch/${anime.slug}`}>
            <Button size="lg" className="rounded-full gap-2">
              <Play className="h-5 w-5 fill-current" />
              Watch Now
            </Button>
          </Link>
          <Button
            size="sm"
            variant="outline"
            className="rounded-full gap-2 bg-transparent"
            onClick={(e) => {
              e.preventDefault()
              onAddToWatchlist?.()
            }}
          >
            {isInWatchlist ? (
              <>
                <Check className="h-4 w-4" />
                In Watchlist
              </>
            ) : (
              <>
                <Plus className="h-4 w-4" />
                Add to List
              </>
            )}
          </Button>
        </div>

        {/* Bottom Content */}
        <div className="absolute bottom-0 left-0 right-0 p-3">
          <h3 className="font-semibold text-white text-sm line-clamp-2 mb-1">{anime.title}</h3>
          <div className="flex items-center gap-2 text-xs text-gray-300">
            {anime.year && <span>{anime.year}</span>}
            {anime.totalEpisodes && (
              <>
                <span>•</span>
                <span>{anime.totalEpisodes} Eps</span>
              </>
            )}
            {anime.status && (
              <>
                <span>•</span>
                <Badge variant="outline" className="text-[10px] px-1.5 py-0 border-white/30 text-white">
                  {anime.status}
                </Badge>
              </>
            )}
          </div>
          {anime.language && anime.language.length > 0 && (
            <div className="flex gap-1 mt-2">
              {anime.language.slice(0, 3).map((lang) => (
                <Badge
                  key={lang}
                  variant="secondary"
                  className="text-[10px] px-1.5 py-0 bg-primary/20 text-primary-foreground"
                >
                  {lang}
                </Badge>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
