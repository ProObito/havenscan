"use client"

import { useTheme } from "@/contexts/theme-context"
import { useEffect, useRef } from "react"

// Particle animation for special themes
export function ThemeAnimations() {
  const { theme } = useTheme()
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animationRef = useRef<number>()

  useEffect(() => {
    if (!theme.animation || !canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas size
    const resize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }
    resize()
    window.addEventListener("resize", resize)

    // Particle system
    interface Particle {
      x: number
      y: number
      size: number
      speedX: number
      speedY: number
      opacity: number
      color: string
    }

    const particles: Particle[] = []
    const particleCount = theme.animation === "galaxy" ? 200 : 50

    // Initialize particles based on animation type
    for (let i = 0; i < particleCount; i++) {
      const particle: Particle = {
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 4 + 1,
        speedX: 0,
        speedY: 0,
        opacity: Math.random() * 0.5 + 0.3,
        color: theme.colors.primary,
      }

      switch (theme.animation) {
        case "sakura":
          particle.speedX = Math.random() * 1 - 0.5
          particle.speedY = Math.random() * 2 + 1
          particle.color = "#f9a8d4"
          particle.size = Math.random() * 8 + 4
          break
        case "rain":
          particle.speedX = 0.5
          particle.speedY = Math.random() * 10 + 10
          particle.color = "#60a5fa"
          particle.size = Math.random() * 2 + 1
          break
        case "snow":
          particle.speedX = Math.random() * 1 - 0.5
          particle.speedY = Math.random() * 1 + 0.5
          particle.color = "#e2e8f0"
          particle.size = Math.random() * 4 + 2
          break
        case "ember":
        case "flame":
          particle.speedX = Math.random() * 2 - 1
          particle.speedY = -(Math.random() * 2 + 1)
          particle.color = Math.random() > 0.5 ? "#f97316" : "#fbbf24"
          particle.y = canvas.height + 20
          break
        case "galaxy":
          particle.speedX = (Math.random() - 0.5) * 0.5
          particle.speedY = (Math.random() - 0.5) * 0.5
          particle.color = Math.random() > 0.7 ? "#c4b5fd" : "#ffffff"
          particle.size = Math.random() * 2 + 0.5
          break
        default:
          particle.speedX = Math.random() * 0.5 - 0.25
          particle.speedY = Math.random() * 0.5 - 0.25
      }

      particles.push(particle)
    }

    // Animation loop
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      particles.forEach((p) => {
        // Update position
        p.x += p.speedX
        p.y += p.speedY

        // Reset particles that go off screen
        if (p.y > canvas.height + 20) {
          p.y = -20
          p.x = Math.random() * canvas.width
        }
        if (p.y < -20 && (theme.animation === "ember" || theme.animation === "flame")) {
          p.y = canvas.height + 20
          p.x = Math.random() * canvas.width
        }
        if (p.x > canvas.width + 20) p.x = -20
        if (p.x < -20) p.x = canvas.width + 20

        // Draw particle
        ctx.beginPath()
        ctx.globalAlpha = p.opacity

        if (theme.animation === "sakura") {
          // Draw petal shape
          ctx.ellipse(p.x, p.y, p.size, p.size * 0.6, Math.PI / 4, 0, Math.PI * 2)
          ctx.fillStyle = p.color
          ctx.fill()
        } else if (theme.animation === "rain") {
          // Draw rain drop
          ctx.moveTo(p.x, p.y)
          ctx.lineTo(p.x + 0.5, p.y + p.size * 5)
          ctx.strokeStyle = p.color
          ctx.lineWidth = 1
          ctx.stroke()
        } else {
          // Draw circle
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2)
          ctx.fillStyle = p.color
          ctx.fill()
        }
      })

      animationRef.current = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", resize)
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [theme])

  if (!theme.animation) return null

  return <canvas ref={canvasRef} className="fixed inset-0 pointer-events-none z-0" style={{ opacity: 0.6 }} />
}
