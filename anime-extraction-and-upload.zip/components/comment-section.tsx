"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Heart, Reply, MoreHorizontal, Send } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Comment } from "@/lib/types"

interface CommentSectionProps {
  seriesId: string
  episodeId?: string
  comments: Comment[]
  onAddComment: (content: string) => Promise<void>
  onLikeComment: (commentId: string) => Promise<void>
}

export function CommentSection({ comments, onAddComment, onLikeComment }: CommentSectionProps) {
  const { user } = useAuth()
  const [newComment, setNewComment] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [replyingTo, setReplyingTo] = useState<string | null>(null)

  const handleSubmit = async () => {
    if (!newComment.trim() || !user) return

    setIsSubmitting(true)
    try {
      await onAddComment(newComment)
      setNewComment("")
    } finally {
      setIsSubmitting(false)
    }
  }

  const formatDate = (date: Date) => {
    const d = new Date(date)
    return d.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    })
  }

  return (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold">Comments ({comments.length})</h3>

      {/* New Comment Form */}
      {user ? (
        <div className="flex gap-3">
          <Avatar className="h-10 w-10">
            <AvatarImage src={user.avatar || "/placeholder.svg"} />
            <AvatarFallback>{user.displayName.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="flex-1 space-y-2">
            <Textarea
              placeholder="Add a comment..."
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              className="min-h-[80px] resize-none"
            />
            <div className="flex justify-end">
              <Button onClick={handleSubmit} disabled={!newComment.trim() || isSubmitting} className="gap-2">
                <Send className="h-4 w-4" />
                Post Comment
              </Button>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-6 bg-muted/50 rounded-lg">
          <p className="text-muted-foreground">
            Please{" "}
            <a href="/login" className="text-primary hover:underline">
              login
            </a>{" "}
            to comment
          </p>
        </div>
      )}

      {/* Comments List */}
      <div className="space-y-4">
        {comments.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">No comments yet. Be the first to comment!</p>
        ) : (
          comments.map((comment) => (
            <div key={comment._id} className="flex gap-3">
              <Avatar className="h-10 w-10">
                <AvatarFallback>U</AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-sm">User</span>
                  <span className="text-xs text-muted-foreground">{formatDate(comment.createdAt)}</span>
                </div>
                <p className="text-sm text-foreground/90">{comment.content}</p>
                <div className="flex items-center gap-4 pt-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    className={cn("h-7 px-2 text-xs gap-1", comment.likes.includes(user?._id || "") && "text-red-500")}
                    onClick={() => onLikeComment(comment._id || "")}
                  >
                    <Heart className={cn("h-3.5 w-3.5", comment.likes.includes(user?._id || "") && "fill-current")} />
                    {comment.likes.length}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 px-2 text-xs gap-1"
                    onClick={() => setReplyingTo(comment._id || null)}
                  >
                    <Reply className="h-3.5 w-3.5" />
                    Reply
                  </Button>
                  <Button variant="ghost" size="sm" className="h-7 px-2">
                    <MoreHorizontal className="h-3.5 w-3.5" />
                  </Button>
                </div>

                {/* Replies */}
                {comment.replies && comment.replies.length > 0 && (
                  <div className="mt-3 space-y-3 pl-4 border-l-2 border-border">
                    {comment.replies.map((reply, idx) => (
                      <div key={idx} className="flex gap-2">
                        <Avatar className="h-7 w-7">
                          <AvatarFallback>R</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-xs">User</span>
                            <span className="text-xs text-muted-foreground">{formatDate(reply.createdAt)}</span>
                          </div>
                          <p className="text-xs text-foreground/90">{reply.content}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Reply Input */}
                {replyingTo === comment._id && (
                  <div className="mt-2 flex gap-2">
                    <Textarea placeholder="Write a reply..." className="min-h-[60px] text-sm" />
                    <div className="flex flex-col gap-1">
                      <Button size="sm">Reply</Button>
                      <Button size="sm" variant="ghost" onClick={() => setReplyingTo(null)}>
                        Cancel
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
