"use client"

import type React from "react"
import { createContext, useContext, useEffect, useState, useCallback } from "react"
import { allThemes, getThemeById } from "@/lib/themes"
import type { Theme } from "@/lib/types"

interface ThemeContextType {
  theme: Theme
  setTheme: (themeId: string) => void
  themes: Theme[]
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setThemeState] = useState<Theme>(allThemes[0]) // Moonlight default

  // Apply theme CSS variables
  const applyTheme = useCallback((t: Theme) => {
    const root = document.documentElement

    root.style.setProperty("--background", t.colors.background)
    root.style.setProperty("--foreground", t.colors.foreground)
    root.style.setProperty("--card", t.colors.card)
    root.style.setProperty("--card-foreground", t.colors.cardForeground)
    root.style.setProperty("--primary", t.colors.primary)
    root.style.setProperty("--primary-foreground", t.colors.primaryForeground)
    root.style.setProperty("--secondary", t.colors.secondary)
    root.style.setProperty("--secondary-foreground", t.colors.secondaryForeground)
    root.style.setProperty("--muted", t.colors.muted)
    root.style.setProperty("--muted-foreground", t.colors.mutedForeground)
    root.style.setProperty("--accent", t.colors.accent)
    root.style.setProperty("--accent-foreground", t.colors.accentForeground)
    root.style.setProperty("--border", t.colors.border)
    root.style.setProperty("--ring", t.colors.ring)

    // Set dark class based on theme mode
    if (t.mode === "dark" || t.mode === "special") {
      root.classList.add("dark")
    } else {
      root.classList.remove("dark")
    }

    // Store animation type for special themes
    if (t.animation) {
      root.setAttribute("data-animation", t.animation)
    } else {
      root.removeAttribute("data-animation")
    }
  }, [])

  // Load saved theme on mount
  useEffect(() => {
    const savedThemeId = localStorage.getItem("anicrew-theme")
    if (savedThemeId) {
      const savedTheme = getThemeById(savedThemeId)
      if (savedTheme) {
        setThemeState(savedTheme)
        applyTheme(savedTheme)
      }
    } else {
      applyTheme(theme)
    }
  }, [applyTheme, theme])

  // Set theme and save
  const setTheme = useCallback(
    (themeId: string) => {
      const newTheme = getThemeById(themeId)
      if (newTheme) {
        setThemeState(newTheme)
        applyTheme(newTheme)
        localStorage.setItem("anicrew-theme", themeId)
      }
    },
    [applyTheme],
  )

  return <ThemeContext.Provider value={{ theme, setTheme, themes: allThemes }}>{children}</ThemeContext.Provider>
}

export function useTheme() {
  const context = useContext(ThemeContext)
  if (!context) {
    throw new Error("useTheme must be used within a ThemeProvider")
  }
  return context
}
