"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect, useCallback } from "react"
import type { User } from "@/lib/types"

interface AuthContextType {
  user: User | null
  loading: boolean
  login: (email: string, username: string) => Promise<void>
  loginWithGoogle: () => Promise<void>
  logout: () => void
  updateProfile: (data: Partial<User>) => Promise<void>
  isPremium: boolean
  isAdmin: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  // Load user from localStorage on mount
  useEffect(() => {
    const savedUser = localStorage.getItem("anicrew-user")
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser))
      } catch {
        localStorage.removeItem("anicrew-user")
      }
    }
    setLoading(false)
  }, [])

  // Simple login (demo - replace with real auth)
  const login = useCallback(async (email: string, username: string) => {
    const newUser: User = {
      _id: `user_${Date.now()}`,
      email,
      username,
      displayName: username,
      role: "user",
      watchlist: [],
      watchHistory: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    setUser(newUser)
    localStorage.setItem("anicrew-user", JSON.stringify(newUser))
  }, [])

  // Google login (demo)
  const loginWithGoogle = useCallback(async () => {
    // In production, implement Google OAuth
    const newUser: User = {
      _id: `google_${Date.now()}`,
      googleId: `g_${Date.now()}`,
      email: "demo@gmail.com",
      username: `user_${Date.now().toString(36)}`,
      displayName: "Google User",
      avatar: "/anime-avatar.png",
      role: "user",
      watchlist: [],
      watchHistory: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    setUser(newUser)
    localStorage.setItem("anicrew-user", JSON.stringify(newUser))
  }, [])

  const logout = useCallback(() => {
    setUser(null)
    localStorage.removeItem("anicrew-user")
  }, [])

  const updateProfile = useCallback(
    async (data: Partial<User>) => {
      if (!user) return

      const updatedUser = { ...user, ...data, updatedAt: new Date() }
      setUser(updatedUser)
      localStorage.setItem("anicrew-user", JSON.stringify(updatedUser))
    },
    [user],
  )

  const isPremium = user?.role === "premium" || user?.role === "admin" || user?.role === "owner"
  const isAdmin = user?.role === "admin" || user?.role === "owner"

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        login,
        loginWithGoogle,
        logout,
        updateProfile,
        isPremium,
        isAdmin,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
